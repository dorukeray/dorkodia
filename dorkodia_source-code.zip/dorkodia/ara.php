<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneleri
	if(!$isLoggedIn) {
		$dorAuth->redirectForLogin($dorkodia->getCurrentDocument());
	} else {
		$currentUserID = $currentUser->getID();
		$dorkodia->connectToDreamchaserService();
		$dorkodia->connectToDatabaseService();
		$activityReporter = new Activity();
		if (isset($_GET['q'])) {
			if(!empty($_GET['q']) && $_GET['q'] != " " && $_GET['q'] != "&amp;") {
				$q = htmlspecialchars($_GET['q']);
				$dreamRequester = new Dream();
				$noteRequester = new Note();
				$thoughtRequester = new Thought();
				$dreamFeed = $dreamRequester->searchDream($q, $currentUserID);
				$noteFeed = $noteRequester->searchNote($q, $currentUserID);
				$thoughtFeed = $thoughtRequester->searchThought($q, $currentUserID);
			}
		}
	}
?>
<!DOCTYPE html>
<html lang="tr" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Ara - Dorkodia</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="shortcut icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
  </head>
  <body>
    <div id="book">
            <?php require_once "./req/header.php"; ?>
      <div id="pod">
        <?php require_once "./req/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1>Ara</h1>
        </div>
        <div id="content">
          <div class="column base-column">
					<?php require_once REQ_DIR."/error-handler.php"; ?>
          <div class="set" id="dreamwall">
            <h2>Arama Sonuçları</h2>
						<p>Yandaki kutudan bir arama yaptığında sonuçları görebilirsin.</p>
            <div class="dreamwall-my-dreamlist">
							<?php
								$thought = new Thought();
								$note = new Note();
								if ($dreamFeed == false && $noteFeed == false && $thoughtFeed == false) {
									echo "<p style='font-family:Ubuntu; color:#444; text-align:center;'>Aradığınız şey bulunamadı.</p>";
								} else {
									if ($dreamFeed != false)
										$dreamResultCount = count($dreamFeed);
									else $dreamResultCount = 0;
									if ($noteFeed != false)
										$noteResultCount = count($noteFeed);
									else $noteResultCount = 0;
									if ($thoughtFeed != false)
										$thoughtResultCount = count($dreamFeed);
									else $thoughtResultCount = 0;
									//result info text
									echo "<p style='font-family:Ubuntu; color:#444; margin:10px 0;'>Bu aramayla ilgili 0.".rand(140, 700)." saniye içinde ". ($dreamResultCount + $noteResultCount + $thoughtResultCount) ." sonuç bulundu.</p>";
									if (is_array($dreamFeed) && (count($dreamFeed) > 0)) {
										$dream = new Dream();
										//arama sonuçlarını burada bastırıyoruz
										foreach ($dreamFeed as $dreamArray) {
											$dream->getDreamByArray($dreamArray);
											$tag = '';
											switch ($dream->getIsReached()) {
												case 1:
													$tag = 'Ulaşılmış Hayal';
													break;
												case 0:
													$tag = 'Hayal';
													break;
											}
											echo '<div class="post do-dream">
														<div class="icon d-cloud-2"></div>
														<div class="post-body">
															<div class="post-info">
																<p class="p-info-username">'.$currentUser->getUsername().'</p><p class="p-info-timestamp">'.$dream->getTimestamp().'</p>
															</div>
															<div class="post-content">
																<h5><span>'.$tag.' &bull; </span>'.$dream->getTitle().'</h5>
																<p>'.$dream->getExplanation().'</p>
															</div>
														</div>
													</div>';
										}
									}	if (is_array($thoughtFeed) && (count($thoughtFeed) > 0)) {
										foreach ($thoughtFeed as $thoughtArray) {
											$thought->getThoughtByArray($thoughtArray);
											echo '<div class="post do-think">
														<div class="icon d-quote"></div>
														<div class="post-body">
															<div class="post-info">
																<p class="p-info-username">'.$currentUser->getUsername().'</p><p class="p-info-timestamp">'.$thought->getTimestamp().'</p>
															</div>
															<div class="post-content">
																<h5><span>Durum &bull; </span>Düşünce Akışı</h5>
																<p>'.$thought->getContent().'</p>
															</div>
														</div>
													</div>';
										}
									}	if (is_array($noteFeed) && (count($noteFeed) > 0)) {
										foreach ($noteFeed as $noteArray) {
											$note->getNoteByArray($noteArray);
											echo '<div class="post do-note">
														<div class="icon d-script"></div>
														<div class="post-body">
															<div class="post-info">
																<p class="p-info-username">'.$currentUser->getUsername().'</p><p class="p-info-timestamp">'.$note->getCreateTime().'</p>
															</div>
															<div class="post-content">
																<h5><span>Not &bull; </span>'.$note->getTitle().'</h5>
																<p>'.$note->getContent().'</p>
															</div>
														</div>
													</div>';
										}
									}
								}
							?>
          	</div>
        </div>
      </div>
			<div class="column nav-column">
				<?php require_once REQ_DIR.'/nanofeed.php'; ?>
			</div>
    </div>
		<?php require_once "./req/footer.php" ?>
  </body>
</html>
