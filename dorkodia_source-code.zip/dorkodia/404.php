<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneler
?>
<!DOCTYPE html>
<html lang="tr" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>404 Bulunamadı - Dorkodia.</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="shortcut icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
  </head>
  <body>
    <div id="book">
         <?php require_once "./req/header.php"; ?>
      <div id="pod">
			<?php require_once "./req/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1>404 Bulunamadı</h1>
        </div>
        <div id="content" class="intro">
          <div class="column base-column">
            <div class="set intro">
              <h2 class="statement">Girmeye çabaladığın yer bulunamadı. Sanıyoruz ki yok :(</h2>
              <p>Anasayfaya dönebilir veya merakını etraftaki bağlantılarla giderebilirsin.</p>
              <ul class="disc-bullets">
				<li><span><a href="index.php">Anasayfaya git.</a></span></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <?php require_once "./req/footer.php" ?>
    </div>
  </body>
</html>
