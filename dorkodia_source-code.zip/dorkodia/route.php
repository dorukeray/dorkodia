<?php
	define('MAIN_DIR', __DIR__);
	define('MICROSERVICE_DIR', MAIN_DIR."/microservice");
	define('IMAGE_DIR', MAIN_DIR."/image");
	define('SCRIPT_DIR', MAIN_DIR."/script");
	define('REQ_DIR', MAIN_DIR."/req");
	define('KERNEL_DIR', MICROSERVICE_DIR."/dorkodia-kernel");
	define('DREAM_DIR', MICROSERVICE_DIR."/dreamchaser");
	define('USER_DIR', MICROSERVICE_DIR."/user");
	define('RESTAPI_DIR', MICROSERVICE_DIR."/restAPI");
	define('SESSAUTH_DIR', MICROSERVICE_DIR."/session-authentication");
	define('LOCALSTORAGE_DIR', MICROSERVICE_DIR."/localstorage");
	define('DB_DIR', MICROSERVICE_DIR."/database");
	define('LOG_DIR', MAIN_DIR."/log");
	define('FILESYS', MAIN_DIR."/dorkodia-filesys");
