<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneleri
	$tabTitle = 'Başlarken';
	$tabContent = '<h2>Dorkodia\'ya Başlarken</h2>
	<p>Dorkodia sadece bir hayal takipçisi değil, aynı zamanda insanların hayalleri ve ilgi alanları çevresinde kurulan bir ayna dünya.</p>
	<img src="./image/tour/homepage.png" class="medium-image">
	<p>Burada seninle aynı hayalleri paylaşan diğer insanlarla iletişime geçebilirsin.</p>
	<h3>Herkes Dorkodia\'ya Kaydolabilir</h3>
	<img src="./image/tour/register.png" class="medium-image">
	<p>Herhangi biri Dorkodia\'yı kullanabilir. <span style="font-family:Roboto;">Bu özgürlüktür, saf bilgi kadar.</span> Bu bir ayrıcalıktan öte özgür ve geniş bir ortam sağlar. Tanıdığın birisiyle burada karşılaşabilirsin. Bu tesadüf değildir <b>:D</b></p>
	';
	if(isset($_GET['tab'])) {
		if(!empty($_GET['tab'])) {
			$tab = $_GET['tab'];
			switch ($tab) {
				case 'baslarken':
					$tabTitle = 'Başlarken';
					$tabContent = '<h2>Dorkodia\'ya Başlarken</h2>
					<p>Dorkodia sadece bir hayal takipçisi değil, aynı zamanda insanların hayalleri ve ilgi alanları çevresinde kurulan bir ayna dünya.</p>
					<img src="./image/tour/homepage.png" class="medium-image">
					<p>Burada seninle aynı hayalleri paylaşan diğer insanlarla iletişime geçebilirsin.</p>
					<h3>Herkes Dorkodia\'ya Kaydolabilir</h3>
					<p>Herhangi biri Dorkodia\'yı kullanabilir. <span style="font-family:Roboto;">Bu özgürlüktür, saf bilgi kadar.</span> Bu bir ayrıcalıktan öte özgür ve geniş bir ortam sağlar. Tanıdığın birisiyle burada karşılaşabilirsin. Bu tesadüf değildir <b>:D</b></p>
					<img src="./image/tour/register.png" class="medium-image">
					';
					break;
				case 'hayal':
					$tabTitle = 'Hayal Takipçisi';
					$tabContent = '<h2>Hayal Takipçisi</h2>
					<p>Dorkodia\'da hayallerini ve onlara nasıl ulaşabileceğini bulanık düşüncelerden süzerek net kalıplarla ifade edersin. Bu sayede hayallerinin üzerinde daha rahat çalışabilirsin. Soyut düşünceleri somut bir şekilde görerek hayallerine bağlı kalabilirsin.</p>
					<img src="./image/tour/dream.png" class="medium-image">
					<p>Bir hayalin varsa ona ulaşıp ulaşmadığını yoklarsın. Ulaştığın hayallerinin listesini her gördüğünde daha çok çalışırsın. Bu seni hayallerine bağlar.</p>
					<img src="./image/tour/dream-donelist.png" class="medium-image">
					';
					break;
				case 'olup-biten':
					$tabTitle = 'Olup Bitenler';
					$tabContent = '<h2>Olup Bitenler</h2>
					<p>Dorkodia bir hayal takipçisi olmasının yanısıra sana zamanın ruhunu da sunar. Anda kalabilmen için...</p>
					<h4>Hayal Duvarı</h4>
					<p>Hayal Duvarı senin için burada neler olup bittiğini gösterdiğimiz bir içerik akışıdır.</p>
					<img src="./image/tour/dreamfeed.png" class="medium-image">
					<p>Senin son etkinliğin, yer imlerindeki kişilerin yaptıkları, Dorkodia\'daki önemli olaylar gibi birtakım şeylerden oluşur.</p>
					<p>Bunun için ilgi alanlarınla beraber bağlantılı olduğun kişileri algoritmada kullanarak senin en çok etkileşime geçebileceğin içerikleri getiriyoruz.</p>
					<h4>Nano Akış</h4>
					<img src="./image/tour/nanofeed.png" class="medium-image">
					<p>Nano Akış, sana Dorkodia\'nın bir özetini sunan bir yan-akıştır.</p>
					<p>Bildirimler, durumun, seninle paylaşılanlar, etkinlik özeti, olup bitenlerden seçmeler, duyurular, kağıt-uçaklar...</p>
					';
					break;
				case 'dusunce-not':
					$tabTitle = 'Düşünceler ve Notlar';
					$tabContent = '<h2>Düşünceler ve Notlar</h2>
					<p>Hayallerini gerçekleştirmek için önce düşünmen sonra da arta kalanları bir yere yazman gerekir.</p>
					<p>İşte Düşünceler ve Notlar bunun için var.</p>
					<h4>Düşünceler</h4>
					<p>Aklından geçenleri Düşünce olarak yazabilirsin. Bu senin için herhangi bir şey olabilir. Bir anı, düşünce, yeni bir buluş, bir konuyla ilgili görüşün, durumun...</p>
					<img src="./image/tour/thought.png" class="medium-image">
					<p>Senin en sonki düşüncen, Durumunu oluşturur. Durumunu kimlerin görebileceğini Gizliliğim sayfandan ayarlayabilirsin.</p>
					<h4>Notlar</h4>
					<p>Notlar, senin yaşamında olup bitenleri yazabileceğin bir çeşit yazılı gönderilerdir.</p>
					<img src="./image/tour/note.png" class="medium-image">
					<p>Bir kenarda dursun dediğin şeyleri not alabilirsin. Notlarına fotoğraflar ekleyebilir, yer imlerindeki insanlardan bahsedebilirsin.</p>
					';
					break;
				case 'hesap':
					$tabTitle = 'Hesabın';
					$tabContent = '<h2>Hesabın</h2>
					<p>Dorkodia ile bir hesaba sahip olursun. Bu hesap senin kim olduğunu gösterir. Bir çeşit ayna kimlik diyebiliriz. Yeni bir internet kişiliği değil, gerçek dünyadaki kimliğinin bir yansıması durumundadır.</p>
					<h4>Hesabını İstediğin Şekilde Düzenleyebilirsin</h4>
					<p>Kendinle ilgili bilgileri hesabına ekleyerek bir çeşit kişisel bilgi kartı oluşturmuş olursun.</p>
					<img src="./image/tour/account.png" class="medium-image">
					<h4>Hesabında Neler Var?</h4>
					<p>İlgi alanların, gözde kitapların, hoşuna giden sözler & filmler, müzik zevkin, uğraşların... Her şeyi ekleyebilirsin.</p>
					<img src="./image/tour/account-info.png" class="medium-image">
					<p>Bunları kimlerin görebileceğini Gizliliğim sayfandan belirleyebilirsin.</p>
					
					';
					break;
				case 'gizlilik':
					$tabTitle = 'Gizlilik';
					$tabContent = '<h2>Gizlilik</h2>
					<p>Dorkodia sana ideallerin çevresinde bir ayna dünyanın kapılarını açar.</p>
					<h4>Topluluğun içinde, Şeffaflık ve Tekillik</h4>
					<p>... bu ayna dünyada kimliğini saklamak istersen, bu senin kararın. Buna saygı duyuyoruz. 
					Kartlarını açık oynamak istemezsen bunu hemen gerçekleştir.</p>
					<img src="./image/tour/privacy.png" class="medium-image">
					<h4>Hesabının Gizliliği</h4>
					<p>Hesabını kimlerin görebileceğine kendin karar ver. Gizlilik mi? Basitleştirildi.</p>
					<img src="./image/tour/privacy-1.png" class="medium-image">		
					<p>Yabancıların seni gözetlemesi, bilginin sızdırılma korkusu... Bunları unut.</p>
					';
					break;
			}
		}
	} else {

	}
?>
<!DOCTYPE html>
<html lang="tr" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>	
    <?php 
		if(isset($tabTitle) && !empty($tabTitle))
			echo $tabTitle;
		else
			echo "Tur";
	 ?> - Dorkodia</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="shortcut icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
    <style>
		.set.synapse ul li {
			height:17px !important;
			padding-left:3px;
		}
		.set.synapse ul li.current a {
			font-size:12px !important;
			font-weight:normal;
			font-family:Roboto;
		}

		.set.synapse ul li i {
			font-size:18px;
			margin:2px;
		}
		.set.synapse ul li a {
			font-size:12px;
			margin-left:5px;
			line-height:17px !important;
		}
    </style>
  </head>
  <body>
    <div id="book">
      <?php require_once "./req/header.php"; ?>
      <div id="pod">
		<?php require_once "./req/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1>Site Turu</h1>
        </div>
        <div id="content">
          <div class="column base-column">
            <div class="set">
				  <?php if(isset($tabContent) && !empty($tabContent)) echo $tabContent; else echo "Burada görecek bir şey yok.";?>
            </div>
          </div>
          <div class="column nav-column">
            <div class="set synapse">
              <h3>Site Turu</h3>
					<?php
						$tabArray = array(
							array('tab'=>"baslarken", 'text'=>"Başlarken", 'icon'=>"world"),
							array('tab'=>"hayal", 'text'=>"Hayal Takipçisi", 'icon'=>"cloud-1"),
							array('tab'=>"olup-biten", 'text'=>"Olup Bitenler", 'icon'=>"news"),
							array('tab'=>"dusunce-not", 'text'=>"Düşünceler ve Notlar", 'icon'=>"bulb"),
							array('tab'=>"hesap", 'text'=>"Hesabın", 'icon'=>"vallet"),
							array('tab'=>"gizlilik", 'text'=>"Gizlilik", 'icon'=>"lock-locker-streamline"),
						);
						echo '<ul>';
						foreach($tabArray as $tabElement) {
							if(isset($_GET['tab']) && ($tabElement['tab'] == $_GET['tab'])) {
								echo '<li class="current"><i class="icon d-'.$tabElement['icon'].'"></i><a style="text-decoration:none !important;">'.$tabElement['text'].'</a></li>';
							} else {
								echo '<li><i class="icon d-'.$tabElement['icon'].'"></i><a href="./tur.php?tab='.$tabElement['tab'].'">'.$tabElement['text'].'</a></li>';
							}
						}
						echo '</ul>';
					?>
				</div>
            <div class="set synapse">
              <h3>Eşsiz ufuklar</h3>
              <p>Dorkodu ve ideallerimiz hakkında <a href="./essiz-ufuklar.php">bilgi edin</a></p>
            </div>
          </div>
        </div>
      </div>
      <?php require_once "./req/footer.php" ?>
    </div>
  </body>
</html>
