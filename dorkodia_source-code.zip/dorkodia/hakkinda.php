<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneleri
?>
<!DOCTYPE html>
<html lang="tr" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Hakkında - Dorkodia</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="shortcut icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
  </head>
  <body>
    <div id="book">
      <?php require_once "./req/header.php"; ?>
      <div id="pod">
        <?php require_once "./req/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1>Dorkodia Hakkında</h1>
        </div>
        <div id="content">
          <div class="column base-column">
            <div class="set">
              <h2>Dorkodia Nedir?</h2>
              <img src="./image/banners/panda.jpeg" class="medium-image">
              <p>Merhaba. Dorkodia'ya hoş geldin. Dorkodia insanların fikir ve hayallerini paylaşabilecekleri, üstünde çalışabilecekleri ve onları gerçekleştirebilecekleri bir platformdur.</p>
              <p class="blog-context"><i class="icon d-quote"></i> Ben Doruk. <strong>Dorkodia</strong>'nın yaratıcısıyım. Kim miyim ben? Tutkulu bir programcı, tasarımcı ve girişimci. <strong>Amacım insanlığın bilgi mirasını korumak ve geliştirmek; onların buna ulaşmasını ve kullanmasını kolaylaştırmak ve Dünya üzerindeki herkese bu hakkı tanımak.</strong><br><br>Dorkodia'yı da yine benim gibiler için geliştirdim. Bir umudu olanlara, hayali olanlara ve onunla dünyayı değiştirebileceğini düşünecek kadar tutkulu olanlara.<br><br>Burada hayallerini kovalayabilir, durumunu gözden geçirebilir ve sonuçlarına hemen ulaşabilrisin. Dorkodia bunun için yaratıldı. <b>Notlar tut, proje yürüt, çalışmalar ekle, günce yaz, zamanını iyi kullan ve verimli çalış!</b></p>
              <a href="./biri.php?u=doruk">Beni bi' yokla.<i class="icon d-external-link"></i></a>
            </div>
            <div class="set">
              <h2>İnsanlar</h2>
              <p><b>Doruk Dorkodu</b> - <b>Yaratıcı</b>, Yazılım Mimarı ve Tasarımcı.</p>
              <p>Bu devrimin bir parçası olmak ister misin? Şuraya bir <a href="./buldum.php">göz at :D</a></p>
            </div>
          </div>
          <div class="column nav-column">
            <div class="set synapse">
              <h3>Eşsiz ufuklar</h3>
              <p>Dorkodu ve ideallerimiz hakkında <a href="./essiz-ufuklar.php">bilgi edin</a></p>
            </div>
            <div class="set synapse">
              <h3>Dorkodu'ya Katıl</h3>
              <p>Dorkodu'daki arananlar listesi için <a href="./buldum.php">buraya</a> bir göz at.</p>
            </div>
            <div class="set synapse">
              <h3>Meraklısı İçin</h3>
              <p>Dorkodia içinde <a href="./yardim.php?tab=sss">sıkça sorulan sorular</a>.</p>
            </div>
            <div class="set synapse">
              <h3>Fibula</h3>
              <p>Dorkodu'daki son konuşulanlar için; bilim, sanat ve kültür hakkında; Fibula'ya göz at.</p>
            </div>
          </div>
        </div>
      </div>
      <?php require_once "./req/footer.php" ?>
    </div>
  </body>
</html>
