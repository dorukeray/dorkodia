<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneleri
	//form gönderildi.
	if(isset($_POST['challange']) && isset($_POST['username']) && isset($_POST['pass'])) {
		$loginToken = $_POST['challange'];
		$uName = $_POST['username'];
		$uPass = $_POST['pass'];
		$uToken = $currentSession->getWebSession('dorkodia_loginToken');

		//oturumu sonlandır
		$dorAuth->freshSession($currentSession);
		//şimdi giriş yap
		if ($loginToken == $uToken) {
			$loginResponse = $dorAuth->doLogin($uName, $uPass);
			if((is_array($loginResponse) && $loginResponse[0] == false) || $loginResponse == false) {
				$dorAuth->redirectToPage($dorkodia->getCurrentDocument().'?result=error&why='.$loginResponse['message']);
			} elseif($loginResponse == true) {
				$currentUser = $dorUser->getUserByUsername($uName);
				//oturum varsa sonlandır, yeni oturum oluştur, logla.
				$currentSession->setSession(session_id(), $currentUser->getID(), $dorAuth->getIP(), $dorAuth->getUserAgent(), sha1($dorAuth->dorcrypted->generateUniqToken(96, RANDOM_BYTES)));
				$dorUser->saveUserToWebSession($currentUser);
				$currentSession->startTheSession();
				if($currentSession->isWebSessionSet('dorkodia_redirectTo')) {
					$dorAuth->redirectToPage($currentSession->getWebSession('dorkodia_redirectTo'));
				} else
					$dorAuth->redirectToPage('anasayfa.php');
			} else {
				$dorAuth->redirectToPage($dorkodia->getCurrentDocument().'?result=error');
			}
		} else {
			$dorAuth->redirectToPage($dorkodia->getCurrentDocument().'?result=error&why=token');
		}
		} else {
		 //eğer login olma isteği yoksa bunları ayarla
		 $dorAuth->freshSession($currentSession);
		 //aman kaybetme bu jeton olmadan çarpışan arabalara binemezsin ona göre.
		 $challange = $dorAuth->generateLoginToken();
		 $currentSession->setWebSession('dorkodia_loginToken', $challange);
		 if (isset($_GET['to'])) {
		 	$currentSession->setWebSession('dorkodia_redirectTo', $_GET['to']);
		 }
	 }
?>
<!DOCTYPE html>
<html lang="tr" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Giriş Yap - Dorkodia</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="shortcut icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
  </head>
  <body>
    <div id="book">
      <?php require_once "./req/header.php"; ?>
      <div id="pod">
      	<?php require_once "./req/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1>Dorkodia'ya Giriş Yap</h1>
        </div>
        <div id="content" class="intro">
          <div class="column base-column">
            <div class="set intro">
							<?php require_once REQ_DIR."/error-handler.php"; ?>
							<br>
              <form class="login-form" action="gir.php" method="post">
                <input type="hidden" id="challange" name="challange" value="<?php echo $challange ?>">
                <div class="form-row">
                  <label for="username">Kullanıcı Adı :</label>
                  <input class="input-text" type="text" name="username" id="username" autocomplete="off">
                </div>
                <div class="form-row">
                  <label for="pass">Parola :</label>
                  <input class="input-text" type="password" name="pass" id="pass">
                </div>
                <div class="form-row button-container">
                  <a href="#">Parolamı unuttum</a>
                  <p>|</p>
                  <button type="submit" name="dologin" id="dologin" onclick="this.disabled=true; this.form.submit();" class="input-submit">Giriş yap</button>
                </div>
            </div>
          </div>
        </div>
      </div>
      <?php require_once "./req/footer.php" ?>
    </div>
  </body>
</html>
