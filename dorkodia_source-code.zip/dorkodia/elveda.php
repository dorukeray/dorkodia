<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneleri
	if(!$isLoggedIn) {
		$dorAuth->redirectForLogin($dorkodia->getCurrentDocument());
	} else {
		$currentUserID = $currentUser->getID();
		$dorkodia->connectToDreamchaserService();
    $dorkodia->connectToDatabaseService();
    if(isset($_POST['delete-my-account']) && isset($_POST['sure'])) {
			$areUSure = $_POST['sure'];
			if (!empty($areUSure) && $areUSure == 1) {
        //kullanıcıyı siliyorum
        $activityRequester = new Activity();
        $dreamRequester = new Dream();
        $noteRequester = new Note();
        $thoughtRequester = new Thought();

        $thoughtRequester->deleteUserBrain($currentUserID);
        $noteRequester->deleteUserNotes($currentUserID);
        $dreamRequester->deleteUserDreams($currentUserID);
        $activityRequester->deleteUserActivity($currentUserID);
        $currentSession->terminateSession();
        $dorUser->destroyUser($currentUserID);
        $dorAuth->redirectToPage('index.php');
		  } else {
        $resultBox = "<div class='message-box error'>
                  <h2>Sanıyoruz Ki Kararın Kesin Değil</h2>
                  <p>Bak hala bir şansın var. Bir daha düşün. <br>Burada hayallerine ulaşacaksın, sana vaadettiğimiz tek şey hakikat. Fazlası Değil.</p>
                  </div>";
      }
	}
}
?>
<!DOCTYPE html>
<html lang="tr" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Hesabım - Dorkodia</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="shortcut icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
  </head>
  <body>
    <div id="book">
      <?php require_once "./req/header.php"; ?>
      <div id="pod">
        <?php require_once "./req/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1>Dorkodia'dan Ayrıl</h1>
        </div><!-- Şş -->
        <div id="content">
          <div class="column base-column">
						<?php require_once REQ_DIR."/error-handler.php"; ?>
            <div class="set">
              <div class="my-account-set">
                <h2>Hesabımı Sil</h2>
								<p>Henüz bir sosyal ağa dönüşmedik. Daha ilk günlerdeyiz ve bir süre tek başına takılacaksın. Eğer bu yüzden sıkıldıysan veya herhangi bir sebeple Dorkodia hesabını silmek ve uzaklaşmak istersen bu senin kararın; ve buna saygı duyuyuoruz.<br><br><b>Şu anda hesabını silmek üzeresin.</b></p>
								<br>
								<form action="elveda.php" method="post">
									<div class="form-row">
										<input type="hidden" name="sure" value="1">
										<label for="delete-my-account" style="width:60%; float:left; margin:0 10px; text-align:left;">Son Kararım. Dorkodia'dan Ayrılıyorum.</label>
										<button type="submit" name="delete-my-account" id="delete-my-account" class="input-submit">Hesabımı Sil</button>
									</div>
								</form>
								<br>
							</div>
            </div>
          </div>
          <div class="column nav-column">
            <?php require_once REQ_DIR.'/nanofeed.php'; ?>
          </div>
        </div>
      </div>
      <?php require_once "./req/footer.php" ?>
    </div>
  </body>
</html>
