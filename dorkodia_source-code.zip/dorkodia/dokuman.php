<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneleri
?>
<!DOCTYPE html>
<html lang="tr" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Dokümantasyon - Dorkodia</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="shortcut icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
    <style>
		.set h4 {
			color: #333 !important;
		}
    </style>
  </head>
  <body>
    <div id="book">
      <?php require_once "./req/header.php"; ?>
      <div id="pod">
        <?php require_once "./req/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1>Dokümantasyon</h1>
        </div>
        <div id="content" class="intro">
          <div class="column base-column">
            <div class="message-box warning">
					<h2>Duyuru</h2>
					<p>Dorkodia şimdilik paylaşımlı bir Apache sunucuda barınmaktadır.<br>
					Bu sebeple buradaki PHP yorumcusundaki bir konfigürasyon nedeniyle site içi yönlendirmeler çalışmayabilir. <br><br>Bunun sonucunda gerektiğinde sizi bazen başka bir sayfaya yönlendiremiyoruz, veya gerekli sonuç iletilerini gösteremiyoruz. <br><br>Bunun için bir çözüm bulunana kadar bir süre böyle idare etmemiz gerek. Çok üzgünüz.</p>
            </div>
            <div class="set">
				  <h2>Başlarken</h2>
              <p>Merhaba. Dorkodia'ya hoş geldin. Dorkodia insanların fikir ve hayallerini paylaşabilecekleri, üstünde çalışabilecekleri ve onları gerçekleştirebilecekleri bir platformdur.</p>
              <p class="blog-context">
					<i class="icon d-script"></i> Bu sayfa Dorkodia yazılımıyla ilgili temel teknik ayrıntıları içerir. 
					Bunun dışında merak ettikleriniz için <a href="./yardim.php?tab=destek">Destek</a> bölümünden yararlanabilirsiniz veya <a href="./tur.php">tura katıl</a>abilirsiniz</b></p>
            </div>
            <div class="set">
					<h2>Yazılımın Yola Çıkışı</h2><br>
					<h4>Dorkodia Projesini Başlatma Nedenim</h4>
					<p>Etrafta bir hayal takip uygulaması olması gerektiğini düşündüm. 
					Her saniye zihnimizden yeni fikirler geçiyor. Her gece hayaller kuruyoruz, kimilerimiz için bu gündüz de devam ediyor.
					Her boş anımızda gözlerimiz bir yere dalıyor ve beynimiz bizi müthiş bir düşünce bombardımanına tutuyor. <br><br>İşte bunun için
					bizim tam da ihtiyacımız olan, aklımız için bir araç olmalıydı. Hayallerimizi hedeflere dönüştürüp onların üzerinde derli toplu bir şekilde çalışabileceğimiz,
					düşüncelerimizi saklayabileceğimiz, notlar alabileceğimiz ve yine bize özel bir şey olmalıydı.</p><br>
					<h4>Küçük Başlangıçlar</h4>
					<p>Bunun ilk örneğini, kendim için projelerimi yönetebileceğim, neyin üstünde ne kadar çalıştığımı hesaplayan,
					 bir çeşit sosyal ağ özelliğine de sahip bir masaüstü uygulaması olarak geliştirmiştim.<br><br> Arayüzü mükemmeldi ve temel fonksiyonları bitmişti aslında.</p><br>
					<h2>Yazılımın Felsefesi ve İlkeleri</h2><br>
					<h4>Bağımsızlık, her şeydir</h4>
					<p>... fakat bunu C# .NET ile geliştirmiştim ve biraz hantaldı. Bunun yanında çevrimiçi bir yapıya Microsoft altyapısına bağımlı olarak gitme konusunda çekincelerim vardı.
					 Eğer küresel bir ölçek hedefliyorsam bu bana özgü veya özgür olmalıydı. Sonuçta da kimse bilgisayarına 10 tane eklenti ve framework kurma zahmetine girmezdi.
					</p>
					<h4>Sadelik, şeklin en karmaşık halidir</h4>
					 <p>Sadelik benim en büyük çıkış noktamdı. Bu şey sade olmalıydı, ama basit değil.
					  Sofistike ama bunu belli etmemeliydi. İçten olmalıydı. Bunun için kullandığım dile, tasarıma, işlevlere özen gözterdim. Gereksiz özellikleri çıkardım.</p>
					<h4>Özgür Yazılım Kültürü</h4>
					<img src="./image/tux" class="small-image" style="display:inline; width:130px; height:auto; float:left; margin-right:10px; border:0;"/>
					
					<br><p><i class="icon d-quote"></i>... en büyük çekincem, başkasına bağımlı olmaktı. Her büyük proje teknolojide ve kültürde bir devrim yapar.
					Eğer öyleyse benim de özgür yazılım kullanmam gerekiyordu. Sadece kendi hünerlerimi konuşturacağım, başka
					hiç bir şeyden endişelenmeyeceğim büyük bir topluluğun parçası olmam gerekiyordu.<br><br>
					Şimdi de biraz teknik detaylardan bahsedelim :</p>
					<br>
					<ul class="disc-bullets">
						<li><span>Yazılımı sıfırdan tamamen <b>Linux</b><img src="./image/251362.gif" style="display:inline;"/> ortamında gelilştirdim. <b>Lubuntu 10.04 ve 18.04</b> sürümlerinde, <b>256MB ve 4GB</b>
						 olarak iki RAM'de, <b>Intel Celeron 2003</b> ve <b>Intel i5</b> iki işlemcide test ettim.</span></li>
						<li><span>Kod editörü olarak <b>Atom</b> kullandım.</span></li>
						<li><span><b>Firefox Nighty ve Chromium</b> tarayıcılarda test ettim.</span></li>
						<li><span>Yazarken bir betik dili olan <b>PHP</b> kullandım.</span></li>
						<li><span>Bu nedenle <b>Apache</b> sunucusu ve <b>MySQL</b> veritabanı kullandım.</span></li>
						<li><span>Yazılımı <b>21 günde yaklaşık 160 saatte</b> tamamladım. Bunun 9 günü arayüz tasarımına kalanı yazılımın kendisine harcandı.</span></li>
						<li><span>Bu yayınladığım henüz <b>kuluçka</b> aşamasındaki sürümü. Önümüzdeki zaman diliminde geliştirmeye ve yeni özellikler eklemeye devam edeceğim.</span></li>
					</ul>
					<h2>Yazılım Mimarisi</h2>
					<h4>Seçtiğim Mimari Kalıp</h4>
					<p>Daha hızlı geliştirip canlıya alabilmek için uygulanması ve teorisi kolay bir mimari seçtim.
					Birer kapalı kutu şeklinde birbirinden bağımsız, başka yerde de kullanabileceğim küçük birimlerden
					oluşan bir yazılımı geliştirmek hem kolay hem de hızlıdır. Böylece bana en yakın olan mikroservis kalıbı ilgimi çekti.</p>
					<h4>Mikroservis ve Mikrokernel Kalıplarının Bir Sentezi</h4>
					<p>... Dorkodia'nın bir de merkezi olmalıydı. İleride daha fazla özellik eklenince bunların yönetimi ve eşgüdümünü
					üstlenecek bir çekirdek. Ta da! Mikrokernel kalıbı. Ne kadar uygulayabildiğim tartışılır. Çok fazla tasarım kalıbı kullanmadım bile, bunun için birkaç kitap okuyacağım, faydası olur.</p>
					<br><h2>Sistemin Her Bir Dişlisi</h2>
					<h4>Güvenlik Katmanı - $dorAuth</h4>
					<p>Bir web uygulamasının en önemli ikinci özelliği mutlaka güvenliğidir. Bir saldırıya veya ihmale kurban gitmemek
					için temsili bir güvenlik katmanı geliştirdim. 11 gün bu sürdü. Temel özelliklerin birkaçından feragat etsem de pişman değilim.</p>
					<p>Bu <b>DorkodiaAuthentication</b> sınıfı. <b>Session, Log ve Dorcrypted</b> gibi çeşitli amaçlarla ona bağlı diğer
					nanoserviscikler de var. Organel-Hücre mantığı. Her geçen gün daha da geliştirmem gerekecek, şimdilik yeterli gibi.</p>
					<h4>Kullanıcı Mikroservisi - $dorUser </h4>
					<p>Altında şimdilik sadece bir <b>User</b> sınıfı var, ancak genel olarak işin kullanıcı boyutuyla ilgileniyor. DorAuth ile eşgüdümlü bir ortaklıkla çalışıyor</p>
					<h4>Hayaltakipçisi Mikroservisi</h4>
					<p>İşin bel kemiği burası. <b>Dream, Note, Activity, Thought, Blog, Work</b> gibi çeşitli alt sınıfları kapsıyor. Şimdilik kendi ayrı görevleri yok, yalnızca bağlı olduğu sınıflara bağlı.</p>
					<h4>Dorkodia Çekirdeği</h4>
					<p>Her sayfa için gerekenleri karşılıyor ve Controller görevi üstleniyor. Kendinde tanımlı nesneler yardımıyla diğer mikroservislere bağlanıyoruz. İşler karıştıkça faydası dokunabilir.</p>
					<h4>Veritabanı Mikroservisi - $dorkodiaDB</h4>
					<p>Benim diğer projelerimde de kullandığım bir çeşit isviçre çakısı. İstenen veritabanı bağlantı nesnesi eklenerek aynı anda farklı bağlantılar yapılabiliyor. Şu anlık <b>MysqlConnection</b> sınıfı buna bağlı, diğer veritabanları için de özel bağlantı sınıfları eklenebilir.</p>
					<br><h2>Tasarım ve Arayüz</h2>
					<p>Web uygulamasının en önemli özelliği tasarımıdır. Ve özgün bir sayfa yapısıyla tasarımı bir web yazılımını kurtarabilir.</p>
					<ul class="disc-bullets">
						<li><span>Web tasarımında <b>saf HTML ve CSS</b> kullandım</span></li>
						<li><span>Arayüzü <b>Atom</b> editöründe sıfırdan yazarak geliştirdim. Bu önce zaman kaybı gibi olsa da kalan
						zamanda entegrasyonda kolaylık sağladı. Ayrıca sade HTML - CSS özellikleri sayesinde en az 10 yıllık tarayıcılarla bile uyumlu.</span></li>
						<li><span>Gereken site içi grafikleri <b>GIMP</b>'de tasarladım.</span></li>
						<li><span>Yazılımdaki ikon fontu olan <b>dor.icon</b> Creative Commons lisansı ile <b>Fontastic</b> aracılığıyla oluşturulmuştur.</span></li>
					</ul>
					<br><h2>Yazılım ve Fikri Mülkiyet</h2>
					<p>Dorkodia, <b>Dorkodu</b>'nun bir parçasıdır.</p>
					<p>Dorkodia</p>
					<p>Yazılımın içinde kullanılan bazı resimler var, bunların tümü DuckDuckGo arama motorundan 
					elde ettiğim, telif hakları ya ticari olmayan ya da halka açık olan resimlerdir.</p>
					<p>Yazılımın kullanılmasında <a href="./burokrasi.php?tab=kosullar">Kullanım Koşulları</a> ve <a href="./burokrasi.php?tab=gizlilik">Gizlilik İlkeleri</a> yürürlüktedir.</p>
            </div>
          </div>
        </div>
      </div>
      <?php require_once "./req/footer.php" ?>
    </div>
  </body>
</html>
