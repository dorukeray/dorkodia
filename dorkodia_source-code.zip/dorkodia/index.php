<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneler, bu dosyada tanımlı...
	if($isLoggedIn) {
		$dorAuth->redirectToPage('anasayfa.php');
	}
?>
<!DOCTYPE html>
<html lang="tr" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Dorkodia - Hayaller, basitleştirildi.</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
  </head>
  <body>
    <div id="book">
      <?php require_once "./req/header.php"; ?>
      <div id="pod">
        <?php require_once "./req/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1>Dorkodia'ya hoş geldin!</h1>
        </div>
        <div id="content" class="intro">
          <div class="column base-column">
            <div class="set intro">
              <h2 class="statement">Dorkodia seni hayallerine bağlayan bir araçtır.</h2>
              <p>Dorkodia insanların fikir ve hayallerini paylaşabilecekleri, üstünde çalışabilecekleri ve onları gerçekleştirebilecekleri bir platformdur.</p>
              <p>Dorkodia'yı şunlar için kullanabilirsin :</p>
              <ul class="disc-bullets">
						   <li><span>Hayallerini belirle ve işlerin nasıl gittiğini takip et.</span></li>
						   <li><span>Zamanını yönet ve verimli çalış.</span></li>
						   <li><span>Günce yaz ve notlar tut.</span></li>
					    </ul>
              <div class="welcome-buttons-frontpage">
                <a href="kaydol.php" class="tour-button">
                  <h4><i class="icon d-caret-right"></i>Kaydol</h4>
                  <p>Dorkodia'ya katıl.</p>
                </a>
                <a href="tur.php" class="tour-button">
                  <h4><i class="icon d-caret-right"></i>Tura Katıl</h4>
                  <p>Dorkodia hakkında öğren.</p>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php require_once "./req/footer.php" ?>
    </div>
  </body>
</html>
