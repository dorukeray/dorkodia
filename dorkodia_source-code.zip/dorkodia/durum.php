<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneler, bu dosyada tanımlı...
	if(!$isLoggedIn) {
		$dorAuth->redirectForLogin($dorkodia->getCurrentDocument());
	} else {
		$currentUserID = $currentUser->getID();
		$dorkodia->connectToDreamchaserService();
		$activityReporter = new Activity();
		//not listeleme
		$thoughtRequester = new Thought();

		$resultBox = "";
    if (isset($_POST['post-status'])) {
			$statusText = addslashes(htmlspecialchars($_POST['status-input']));
			$activityReporter = new Activity();

			if (!empty($statusText)) {
				$idea = new Thought();
				$fingerprint = $dorAuth->dorcrypted->generateUniqToken(32, RANDOM_BYTES);
				$idea->setThought(NULL, $currentUserID, $statusText, NULL, $fingerprint);
				$saveResult = $idea->saveThought();
				$activityReporter->setActivity(NULL, "THOUGHT", $currentUserID, NULL, $idea->getThoughtId());
				$reportResult = $activityReporter->saveActivity();

				if($saveResult && $reportResult) {
					$resultBox = "<div class='message-box info'>
										<h2>Ooow kimler gelmiş!</h2>
										<p>Düşünce akışın başarıyla güncellendi.</p>
										</div>";
				} elseif(!$saveResult && !$reportResult) {
					$resultBox = "<div class='message-box error'>
										<h2>Hata</h2>
										<p>Bir hata oluştu. Durumun güncellenemedi.</p>
										</div>";
				} elseif(!$reportResult) {
					$resultBox = "<div class='message-box warning'>
										<h2>Amaa Dostuum Bak </h2>
										<p>Bir hata oluştu. Durumun güncellendi ancak bu sonsuza kadar böyle sürmeyebilir.<br>Bir bakarsın ki hiçbir şey aynı değil...</p>
										</div>";
				} elseif(!$saveResult) {
					$resultBox = "<div class='message-box warning'>
										<h2>Söylemekten Utanıyoruz Ama...</h2>
										<p>İlginç bir sey oldu vee... Sanırım... Durumun güncellenemedi.</p>
										</div>";
				}
			} else {
				$resultBox = "<div class='message-box warning'>
												<h2>Uyarı</h2>
												<p>Bak, burada oyun oynamıyoruz. Lütfen boş yapma. Ciddiyim.</p>
											</div>";
			}
		} elseif(isset($_POST['delete-thought'])) { //dü$ünce silme
			$thoughtID = htmlspecialchars($_POST['thought-id']);
			if (!empty($thoughtID)) {
				$thoughtOne = new Thought();
				$thoughtOne->getThoughtById($thoughtID);
				$activityReporter = new Activity();
				$activityReporter->getActivityByThingId('THOUGHT', $thoughtID);
				$reportResult = $activityReporter->deleteActivity();
				$deleteResult = $thoughtOne->deleteThought();
				if($deleteResult == true && $reportResult == true) {
					$resultBox = "<div class='message-box info'>
										<h2>Bilgi</h2>
										<p>Düşünceni zihninden atmayı başardın.</p>
									  </div>";
				} elseif (!$deleteResult || !$reportResult) {
					$resultBox = "<div class='message-box error'>
										<h2>Hata</h2>
										<p>Bir hata oluştu. Olup biteni bi' kontrol et.</p>
									  </div>";
				}
			} else {
				$resultBox = "<div class='message-box warning'>
									<h2>Garip ?!</h2>
									<p>Böyle bir düşünce yok.</p>
									</div>";
			}
		}
		$userThoughts = $thoughtRequester->getThoughtByUserId($currentUserID);
	}
?>
<!DOCTYPE html>
<html lang="tr" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Durumum - Dorkodia</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="shortcut icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
  </head>
  <body>
    <div id="book">
      <?php require_once "./req/header.php"; ?>
      <div id="pod">
        <?php require_once "./req/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1>Durumum</h1>
        </div>
        <div id="content">
          <div class="column base-column">
				<?php require_once REQ_DIR."/error-handler.php"; ?>
            <div class="set" id="dreamwall">
              <h2>Düşünce Akışım</h2>
              <?php if(!empty($resultBox)) echo $resultBox;?>
              <div class="dreamwall-share-box">
                <form action="<?php echo $dorkodia->getCurrentDocument(); ?>" method="POST">
                  <label for="status-input">Düşünce akışına bir şeyler yaz :</label>
                  <textarea name="status-input" id="status-input" class="input-richtext" autocomplete="off" maxlength="256"></textarea>
                  <button type="submit" name="post-status" id="post-status" class="input-submit">yolla!</button>
                </form>
              </div>
              <!-- not listele -->
              <div class="dreamwall-my-worklist">
                <div class="header-set">
                  <h3>Düşüncelerim</h3>
                </div>
                <div class="wlist-content">
                  <ul>
						<?php
							if (is_array($userThoughts) && (count($userThoughts) > 0)) {
								foreach ($userThoughts as $userThought) {
									$tmpThought = new Thought();
									$tmpThought->getThoughtByArray($userThought);
								  echo '<div class="post do-think">
                        <div class="icon d-quote"></div>
                        <div class="post-body">
                          <div class="post-info">
                            <img src="" class="user-photo">
                            <p class="p-info-username">'.$currentUser->getUsername().'</p><p class="p-info-timestamp">'.$tmpThought->getTimestamp().'</p>
                          </div>
                          <div class="post-content">
                            <h5><span>Durum &bull; </span>Düşünce Akışı</h5>
                            <p>'.$tmpThought->getContent().'</p>
                          </div>
                        </div>
                      </div>
                      <div class="dream-details-controlbox">
											<form action="durum.php" method="POST">
												<input type="hidden" value="'.$tmpThought->getThoughtId().'" name="thought-id"></input>
												<button type="submit" id="work-btn-giveup" name="delete-thought" class="input-submit"><i class="icon d-delete-garbage-streamline"></i> Bilinçaltına Yolla</button>
											</form>
										  </div>';
								}
							} elseif (!$userThoughts) {
								echo "<p style='width:95%; margin:5px auto;'>Zihnin tertemiz. Bilncini kaybetmeden bir şeyler yaz. Aklından neler geçiyor?</p>";
							}
						?>
                  </ul>
                </div>
              </div>
              <div class="dream-">

              </div>
            </div>
          </div>
          <div class="column nav-column">
            <?php require_once REQ_DIR.'/nanofeed.php'; ?>
          </div>
        </div>
      </div>
      <?php require_once "./req/footer.php" ?>
    </div>
  </body>
</html>
