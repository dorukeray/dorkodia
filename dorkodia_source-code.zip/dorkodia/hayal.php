<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneleri
	if(!$isLoggedIn) {
		$dorAuth->redirectForLogin($dorkodia->getCurrentDocument());
	} else {
		$currentUserID = $currentUser->getID();
		$dorkodia->connectToDreamchaserService();
		$activityReporter = new Activity();
		//hayal listeleme
		$dreamRequester = new Dream();

		$resultBox = "";
		if(isset($_POST['new-dream'])) { //hayal ekleme
			$dreamTopic = addslashes(htmlspecialchars($_POST['dream-topic']));
			$dreamExplanation = addslashes(htmlspecialchars($_POST['dream-explanation']));
			$dreamGoals = addslashes(htmlspecialchars($_POST['dream-goals']));

			if (!empty($dreamTopic) && !empty($dreamExplanation) && !empty($dreamGoals)) {
				$dreamNeu = new Dream();
				$fingerprint = $dorAuth->dorcrypted->generateUniqToken(32, RANDOM_BYTES);
				$dreamNeu->setDream(NULL, $currentUserID, $dreamTopic, $dreamExplanation, $dreamGoals, NULL, NULL, $fingerprint);
				$saveResult = $dreamNeu->saveDream();
				$activityReporter->setActivity(NULL, 'DREAM', $currentUserID, NULL, $dreamNeu->getDreamId());
				$reportResult = $activityReporter->saveActivity();

				if($saveResult && $reportResult) {
					$resultBox = "<div class='message-box info'>
										<h2>Bilgi</h2>
										<p>Hayalin başarıyla eklendi.</p>
										</div>";
				} elseif(!$saveResult && !$reportResult) {
					$resultBox = "<div class='message-box error'>
										<h2>Hata</h2>
										<p>Bir hata oluştu. Hayalin eklenemedi.</p>
										</div>";
				} elseif(!$saveResult) {
					$resultBox = "<div class='message-box warning'>
										<h2>Söylemekten Utanıyoruz Ama...</h2>
										<p>İlginç bir sey oldu ve... Hayalin eklenemedi.</p>
										</div>";
				} elseif(!$reportResult) {
					$resultBox = "<div class='message-box warning'>
										<h2>Söylemekten Utanıyoruz Ama...</h2>
										<p>Bir hata oluştu. Hayalin eklendi ancak bu sonsuza kadar böyle sürmeyebilir.</p>
										</div>";
				}
			} else {
				$resultBox = "<div class='message-box warning'>
												<h2>Uyarı</h2>
												<p>Bak, burada oyun oynamıyoruz. Lütfen <b>boş</b> yapma. Ciddiyim?!</p>
											</div>";
			}
		} elseif(isset($_POST['dream-giveup'])) { //hayal silme
			$dreamID = htmlspecialchars($_POST['dream-id']);
			if (!empty($dreamID)) {
				$dreamNeu = new Dream();
				$dreamNeu->getDreamById($dreamID);
				$activityReporter = new Activity();
				$activityReporter->getActivityByThingId('DREAM', $dreamID);
				$reportResult = $activityReporter->deleteActivity();
				$result = $dreamNeu->giveupDream();

				if($result && $reportResult) {
					$resultBox = "<div class='message-box info'>
										<h2>Aradığınız hayale şu anda ulaşılamıyor. Lütfen daha sonra tekrar...</h2>
										<p>Hayalinden başarıyla(!) vazgeçtin. Ya korkaksın ya da boş hayallere kapılmayacak kadar akıllı. Ama ikisi de sana asla bir şey kazandırmayacak.</p>
										</div>";
				} elseif (!$result) {
					$resultBox = "<div class='message-box error'>
										<h2>Hata</h2>
										<p>Bir hata oluştu. Olup biteni bi' kontrol et.</p>
										</div>";
				}
			} else {
				$resultBox = "<div class='message-box error'>
									<h2>Bu... Olamaz.</h2>
									<p>Böyle bir hayal yok.</p>
									</div>";
			}
		} elseif(isset($_POST['dream-complete'])) { //hayal silme
			$dreamID = htmlspecialchars($_POST['dream-id']);
			$dreamNeu = new Dream();
			$dreamNeu->getDreamById($dreamID);
			$result = $dreamNeu->reachDream();
			if($result) {
				$resultBox = "<div class='message-box info'>
									<h2>Tebrikler!</h2>
									<p>Bir hayaline ulaştın. Sanıyoruz ki böyle devam edersen... Neyse övgü için bu kadar yeter.</p>
								  </div>";
			} elseif (!$result) {
				$resultBox = "<div class='message-box error'>
									<h2>Hata</h2>
									<p>Bir hata oluştu. Olup biteni bi' kontrol et.</p>
								  </div>";
			}
	}
	$userDreams = $dreamRequester->getDreamByIsReached($currentUserID, false);
	$userReachedDreams = $dreamRequester->getDreamByIsReached($currentUserID, true);
}
?>
<!DOCTYPE html>
<html lang="tr" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Hayal - Dorkodia</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="shortcut icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
  </head>
  <body>
    <div id="book">
      <?php require_once "./req/header.php"; ?>
      <div id="pod">
				<?php require_once "./req/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1>Hayallerim</h1>
        </div>
        <div id="content">
          <div class="column base-column">
						<?php require_once REQ_DIR."/error-handler.php"; ?>
            <div class="set" id="dreamwall">
              <h2>Hayallerim</h2>
							<?php if(!empty($resultBox)) echo $resultBox;?>
              <div class="dream-new-dream">
                <div class="header-set">
                  <h3>Yeni bir hayal ekle</h3>
                </div>
                <form name="form-new-dream" action="hayal.php" method="POST">
                  <label for="dream-topic">Konu :</label>
                  <input type="text" name="dream-topic" id="dream-topic" class="input-text" autocomplete="off" maxlength="64">
                  <label for="dream-explanation">Açıklama :</label>
                  <input type="text" name="dream-explanation" id="dream-explanation" class="input-text" autocomplete="off" maxlength="256">
                  <label for="dream-goals">Bunu gerçekleştirmek için ne yapman gerekiyor? :</label>
                  <textarea name="dream-goals" id="dream-goals" class="input-richtext" autocomplete="off" maxlength="512"></textarea>
                  <button type="submit" name="new-dream" class="input-submit">Bu hayali kur!</button>
                </form>
              </div>
              <div class="dreamwall-my-dreamlist">
                <div class="header-set">
                  <h3>Hayallerim</h3>
                </div>
                <div class="dlist-content">
                  <ul>
										<?php
											if (is_array($userDreams) && (count($userDreams) > 0)) {
												foreach ($userDreams as $userDream) {
													$tmpDream = new Dream();
													$tmpDream->getDreamByArray($userDream);
													echo '<li><i class="icon d-food-ice-cream-streamline"></i><p>'.$tmpDream->getTitle().'</p><a href="#" onclick="toggleVisible('.$tmpDream->getDreamId().');"><i class="icon d-caret-right end"></i></a></li>
													<div class="dream-details" id="dream-'.$tmpDream->getDreamId().'">
														<div class="dream-details-box">
															<div class="box-column">
																<label>Açıklama : </label>
															</div>
															<div class="box-column-second">
																<p>'.$tmpDream->getExplanation().'</p>
															</div>
														</div>
														<div class="dream-details-box">
															<div class="box-column">
																<label>Gerekenler : </label>
															</div>
															<div class="box-column-second">
																<p>'.$tmpDream->getHowTo().'</p>
															</div>
														</div>
														<div class="dream-details-controlbox">
															<form action="hayal.php" method="post">
																<input type="hidden" name="dream-id" value="'.$tmpDream->getDreamId().'">
																<button type="submit" id="dream-btn-complete" name="dream-complete" class="input-submit">Hayalime ulaştım!</button>
																<button type="submit" id="dream-btn-giveup" name="dream-giveup" class="input-submit">Bundan Vazgeçtim</button>
															</form>
														</div>
													</div>';
												}
											} elseif (!$userDreams) {
												echo "<p style='width:95%; margin:10px auto;'>Zihnin bu aralar boş görünüyor. Yeni bir hayalin peşine düşmenin zamanı gelmedi mi sence?</p>";
											}
										?>

                      <!--<div class="dream-details-feedbox feedbox-works">
                        <h4><i class="icon d-bulb"></i> Çalışmaların</h4>
                        <div class="nanofeed-activity act-work">
                          <div class="nanofeed-activity-content">
                            <p><i class="icon d-file-binary"></i>Dorkodia projesi için dokümantasyon - 1</p>
                            <p class="activity-info-text">22:40</p>
                          </div>
                        </div>
                      </div>
                      <div class="dream-details-feedbox feedbox-notes">
                        <h4><i class="icon d-script"></i> Notların</h4>
                        <div class="nanofeed-activity act-note">
                          <div class="nanofeed-activity-content">
                            <p>bu işin sonu hiç iyiye gitmiyor. çok sıkıldım ve dorkodia artık bitsin!</p>
                            <p class="activity-info-text">Dün, 11:09</p>
                          </div>
                        </div>
                        <div class="nanofeed-activity act-note">
                          <div class="nanofeed-activity-content">
                            <p>daha js var ve hala tasarımı bitiremedim. neden bu kadar az süre verdiniz?</p>
                            <p class="activity-info-text">Dün, 17:24</p>
                          </div>
                        </div>
                      </div>
                      <div class="dream-details-feedbox feedbox-blogs">
                        <h4><i class="icon d-book-1"></i> Güncelerin</h4>
                        <div class="nanofeed-activity act-work">
                          <div class="nanofeed-activity-content">
                            <p>Dorkodia Projesine Giriş #1</p>
                            <p class="activity-info-text">Dün, 11:04</p>
                          </div>
                        </div>
                      </div>-->
                  </ul>
                </div>
								<div class="header-set">
									<h3>Ulaştığım Hayallerim</h3>
								</div>
								<div class="dlist-content">
									<ul>
										<?php
											if (is_array($userReachedDreams) && (count($userReachedDreams) > 0)) {
												foreach ($userReachedDreams as $userDream) {
													$tmpDream = new Dream();
													$tmpDream->getDreamByArray($userDream);
													echo '<div class="post do-dream">
								                <div class="icon d-cloud-2"></div>
								                <div class="post-body">
								                  <div class="post-info">
								                    <p class="p-info-username">'.$currentUser->getUsername().'</p><p class="p-info-timestamp">'.$tmpDream->getTimestamp().'</p>
								                  </div>
								                  <div class="post-content">
								                    <h5><span>Ulaşılmış Hayal &bull; </span>'.$tmpDream->getTitle().'</h5>
								                    <p>'.$tmpDream->getExplanation().'</p>
								                  </div>
								                </div>
								              </div>';
												}
											} elseif (!$userReachedDreams) {
												echo "<p style='width:95%; margin:5px auto;'>Henüz ulaştığın bir hayalin yok :/ Çalışmaya devam et.</p>";
											}
										?>
									</ul>
								</div>
              </div>
            </div>
          </div>
          <div class="column nav-column">
						<?php require_once REQ_DIR.'/nanofeed.php'; ?>
          </div>
        </div>
      </div>
      <?php require_once "./req/footer.php"; ?>
    </div>
  </body>
</html>
