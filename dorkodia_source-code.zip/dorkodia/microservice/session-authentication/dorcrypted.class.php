<?php
	//Dorcrypted security stuff class, will be built for further advanced needs. Dorkodia needs to go global and really change the world.
	define("RANDOM_BYTES", "RANDOM_BYTES");
	define("UNIQID_WAY", "UNIQID_WAY");
	class Dorcrypted {
		public function shuffleString($mainString, $keyLength) {
			//"1234567890qwertyuoplkjhgfdsazxcvbnm_"
			$randStr = str_shuffle($str);
			return substr($randStr, 0, $keyLength);
		}

		public function generateUniqid($startingString = "") {
			return uniqid($startingString, true);
		}

		public function validateTokens($firstToken, $secondToken) {
			return hash_equals($firstToken, $secondToken);
		}

		public function generateUniqToken($length, $technique = "") {
			switch($technique) {
			   case "RANDOM_BYTES":
					 if(function_exists('random_bytes'))
						 $bespokeKey = bin2hex(random_bytes($length)); //uuh, cool words!
				 	 else
						 $bespokeKey = $this->generateUniqid();
					break;
			   case "UNIQID_WAY":
					$bespokeKey = $this->generateUniqid(); //uuh, cool words!
					break;
				case NULL:
				return false;
			}
			return $bespokeKey;
		}

	}
