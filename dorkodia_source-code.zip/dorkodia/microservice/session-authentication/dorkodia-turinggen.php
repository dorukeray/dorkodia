<?php
	session_start();
	$font = "Blurmix_0.TTF";
	$width = "400";
	$height = "50";

  //metin oluşturma motoru buradan

  function randomWord() {
    $words = array('world', 'search', 'dorkodu', 'dreamer', 'goktengri', 'corona', 'bestest', 'hackerway', 'ataturk', 'left-wing', 'ussr91', '666', '1923');
    return $words[rand(0, count($words)-1)];
  }

  $metin = randomWord();

	$image = imagecreate($width,$height);
	imagecolorallocate($image, 220, 239, 229);

	$text_renk = imagecolorallocate($image, 140, 200, 200);
	$bg1 = imagecolorallocate($image, 244, 244, 244);
	$bg2 = imagecolorallocate($image, 227, 239, 253);
	$bg3 = imagecolorallocate($image, 230, 245, 240);

	header('Content-type: image/png');
  //bakalım bunu da çözebilecek misin cici botcuk?
  imagettftext($image, 26, -4, 100, 40, $bg1, $font, str_shuffle($metin));
	imagettftext($image, 26, -4, 10, 40, $bg1, $font, str_shuffle($metin));
  imagettftext($image, 30, -7, 50, 15, $bg2, $font, str_shuffle($metin));
  imagettftext($image, 26, -10, 200, 15, $bg1, $font, str_shuffle($metin));
  imagettftext($image, 34, -20, 13, 34, $bg2, $font, str_shuffle($metin));
  imagettftext($image, 21, -3, 20, 15, $bg1, $font, str_shuffle($metin));
	imagettftext($image, 40, -3, 200, 30, $bg1, $font, str_shuffle($metin));

  //umarım bu epilepsi-killer olmaz
	for( $i = 0; $i < ($width * $height) / 300; $i++ ) {
	   imageline($image, mt_rand(0,$width), mt_rand(0,$height), mt_rand(0,$width), mt_rand(0,$height), $bg3);
  }

  $neuheight = ($height / 2) + 10;
  imagettftext($image, 32, mt_rand(0, 5), mt_rand(10, $width-250), $neuheight, $text_renk, $font, $metin);
  imageline($image, mt_rand(0,$width), mt_rand(0,$height), mt_rand(0,$width), mt_rand(0,$height), $bg3);
  imageline($image, mt_rand(0,$width), mt_rand(0,$height), mt_rand(0,$width), mt_rand(0,$height), $bg3);
  imageline($image, mt_rand(0,$width), mt_rand(0,$height), mt_rand(0,$width), mt_rand(0,$height), $bg3);
  imageline($image, mt_rand(0,$width), mt_rand(0,$height), mt_rand(0,$width), mt_rand(0,$height), $bg3);
  imageline($image, mt_rand(0,$width), mt_rand(0,$height), mt_rand(0,$width), mt_rand(0,$height), $bg3);

	imagepng($image);
	imagedestroy($image);

	$_SESSION['dorkodia_captcha'] = "$metin";
	session_register("dorkodia_captcha");

?>
