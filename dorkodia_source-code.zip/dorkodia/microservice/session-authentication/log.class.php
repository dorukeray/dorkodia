<?php
	//Dorkodia log class
	class Log {
		protected $logType;
		protected $logContent;

		public function writeLog($filename, $logtype, $logcontent) {
			try {
				if(!file_exists(LOG_DIR."/".$filename)) {
					touch(LOG_DIR."/".$filename, "0777");
				}
				$this->logType = $logtype;
				$this->logContent = $logcontent;
				$doc = fopen(LOG_DIR."/".$filename, "ab+");
				fputs($doc, $logtype." - ".$logcontent."\n");
				fclose($doc);
				return true;
			}
			catch(Throwable $e) { return false; }
		}
	}
