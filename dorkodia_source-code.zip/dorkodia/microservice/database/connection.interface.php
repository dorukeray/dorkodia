<?php
	//to scale up the connection arch. this is a beginner version of a connection interface...
	interface ConnectionInterface {		
		public function connect();
	}
?>
