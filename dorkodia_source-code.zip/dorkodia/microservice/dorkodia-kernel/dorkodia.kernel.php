<?php
	//ob_start();
	setlocale(LC_TIME, 'tr_TR');
	error_reporting(0);
	require_once "route.php";
	//declare(strict_types=1);
	//Standard Dorkodia Page.
	class Dorkodia {
		//page properties
		protected $name;
		protected $title;
		protected $headerTitle;
		protected $URL;
		protected $queryString;
		protected $requestMethod;

		public function getRequestMethod() {
			return $_SERVER['REQUEST_METHOD'];
		}

		public function getQueryString() {
			return $_SERVER['QUERY_STRING'];
		}

		public function getCurrentURL() {
			return $_SERVER['PHP_SELF'];
		}

		//sanırım bu get set konusunda kod tekrarı oldu...
		public function getAttr($attribute) {
		  try {
			return $this->$attribute;
		  } catch (Exception $e) {
			return false;
		  }
		}

		public function setAttr($attribute, $value) {
		  try {
				$this->$attribute = $value;
		  } catch (Exception $e) {
			return false;
		  }
		}

		public function connectToAuthenticationService() {
			require_once SESSAUTH_DIR."/dorkodia-auth.microservice.php";
		}

		public function connectToDatabaseService() {
			require_once DB_DIR."/dorkodia-db.microservice.php";
		}

		public function connectToLocalStorageService() {
			require_once LOCALSTORAGE_DIR."/localstorage.microservice.php";
		}

		public function connectToDreamchaserService() {
			require_once DREAM_DIR."/dreamchaser.microservice.php";
		}

		public function connectToUserService() {
			require_once USER_DIR."/user.microservice.php";
		}

		public function getCurrentDocument() {
			$dizi = explode('/', $_SERVER['PHP_SELF']);
			if(!empty($dorkodia->queryString)) {
				$dizi2 = explode('?', $dizi[count($dizi) - 1]);
				return $dizi2[0];
			} else {
				return $dizi[count($dizi) - 1];
			}
		}

		public function setPageEnvironment() {
			$this->name = $this->getCurrentDocument();
			$this->URL = $this->getCurrentURL();
			$this->requestMethod = $this->getRequestMethod();
			$this->queryString = $this->getQueryString();
		}

		public function __construct() {
			$this->setPageEnvironment();
		}
	}

//her sayfada gerekli şeyler şimdilik burada dursun
require_once REQ_DIR."/page.controller.php";
