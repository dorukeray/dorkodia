<?php
	//Dorkodia blog class
	class Thought {
		public $thoughtID;
		public $content;
		public $timestamp;
		public $title;
		public $content;
		public $hit;
		
		
		
	}
