<?php
	//Dorkodia dream class
	require_once DB_DIR."/dorkodia-db.microservice.php";
	class Dream {
		protected $dreamID;
		protected $userID;
		protected $title;
		protected $explanation;
		protected $howTo;
		protected $timestamp;
		protected $isReached;
		protected $fingerprint;

		protected $dorkodiaDB;
		public function __construct() {
			$this->dorkodiaDB = new DorkodiaDB();
		}

		public function setDream($dream_id = NULL, $user_id, $title, $explanation, $howTo, $timestamp = NULL, $is_reached = NULL, $fingerprint) {
			if(!empty($user_id) && !empty($title) && !empty($explanation) && !empty($howTo) && !empty($fingerprint)) {
				if(empty($timestamp)) {
					$this->timestamp = date('Y.m.d H:i:s');
				} else {
					$this->timestamp = $timestamp;
				} if(!empty($dream_id)) {
					$this->dreamID = $dream_id;
				} if(empty($is_reached)) {
					$this->isReached = 0;
				} else {
					$this->isReached = $is_reached;
				}
				$this->userID = $user_id;
				$this->title = $title;
				$this->explanation = $explanation;
				$this->howTo = $howTo;
				$this->fingerprint = $fingerprint;
				return true;
			} else {
				return false;
			}
		}
		//getters -not setters-
		public function getDreamId() {
			return $this->dreamID;
		}

		public function getTitle() {
			return $this->title;
		}

		public function getExplanation() {
			return $this->explanation;
		}

		public function getHowTo() {
			return $this->howTo;
		}

		public function getUserId() {
			return $this->userID;
		}

		public function getTimestamp() {
			return $this->timestamp;
		}

		public function getIsReached() {
			return $this->isReached;
		}

		public function getFingerprint() {
			return $this->fingerprint;
		}

		public function getDreamByArray($array) {
			if (isset($array['dream_id']) && isset($array['dream_userID']) && isset($array['dream_title']) && isset($array['dream_explanation']) && isset($array['dream_howTo'])) {
				if (isset($array['dream_timestamp']) && isset($array['dream_isReached']) && isset($array['dream_fingerprint'])) {
					$this->setDream($array['dream_id'], $array['dream_userID'], $array['dream_title'], $array['dream_explanation'], $array['dream_howTo'], $array['dream_timestamp'], $array['dream_isReached'], $array['dream_fingerprint']);
				} else {
					return false;
				}
			} else
				return false;
		}

		public function isDreamEmpty() {
			if(empty($this->getTitle()) || empty($this->getExplanation()) || empty($this->getHowTo()) || empty($this->getUserId()) || empty($this->getTimestamp()) || empty($this->getIsReached()) || empty($this->getFingerprint())) {
				return true;
			} else {
				return false;
			}
		}

		public function saveDream() {
				$sql = "INSERT INTO dreams (dream_title, dream_explanation, dream_howTo, dream_userID, dream_isReached, dream_fingerprint) VALUES ('{$this->getTitle()}', '{$this->getExplanation()}', '{$this->getHowTo()}', '{$this->getUserId()}', '{$this->getIsReached()}', '{$this->getFingerprint()}');";
				try {
					$this->dorkodiaDB->query($sql);
					$this->getDreamByArray($this->getDreamByFingerprint($this->getFingerprint()));
					return true;
				} catch(Exception $e) {
					echo "<script>alert(".$e->getMessage().");</script>";
				}
		}

		public function deleteDream() {
			try {
				$sql = "DELETE FROM dreams WHERE dream_id='{$this->getDreamId()}' OR dream_fingerprint='{$this->getFingerprint()}';";
				return $this->dorkodiaDB->query($sql);
			} catch(Exception $excpt) {
				return false;
			}
		}

		public function deleteUserDreams($userID) {
			try {
				$sql = "DELETE FROM dreams WHERE dream_userID='$userID';";
				return $this->dorkodiaDB->query($sql);
			} catch(Exception $excpt) {
				return false;
			}
		}

		public function searchDream($q, $userID) {
			$dreamArray = array();
			$sql = "SELECT * FROM dreams WHERE dream_userID=:uid AND (dream_title LIKE '%$q%' OR dream_explanation LIKE '%$q%' OR dream_howTo LIKE '%$q%');";
			$stmt = $this->dorkodiaDB->sude($sql, array(':uid'=>$userID));
			if ($stmt->rowCount()) {
				while ($neuDream = $stmt->fetch(PDO::FETCH_ASSOC))
					array_push($dreamArray, $neuDream);
			} else { return false; }
			return $dreamArray;
		}

		public function getDreamById($dreamID) {
			$sql = "SELECT * FROM dreams WHERE dream_id=:did LIMIT 1;";
			$stmt = $this->dorkodiaDB->sude($sql, array(':did' => $dreamID));
			if ($stmt->rowCount()) {
				while ($neuDream = $stmt->fetch(PDO::FETCH_OBJ))
					$this->setDream($neuDream->dream_id, $neuDream->dream_userID, $neuDream->dream_title, $neuDream->dream_explanation, $neuDream->dream_howTo, $neuDream->dream_timestamp, $neuDream->dream_isReached, $neuDream->dream_fingerprint);
				return true;
			} else { return false; }
		}

		public function getDreamByFingerprint($fingerprint) {
			$sql = "SELECT * FROM dreams WHERE dream_fingerprint=:did LIMIT 1;";
			$stmt = $this->dorkodiaDB->sude($sql, array(':did' => $fingerprint));
			if ($stmt->rowCount()) {
				while ($neuDream = $stmt->fetch(PDO::FETCH_OBJ))
					$this->setDream($neuDream->dream_id, $neuDream->dream_userID, $neuDream->dream_title, $neuDream->dream_explanation, $neuDream->dream_howTo, $neuDream->dream_timestamp, $neuDream->dream_isReached, $neuDream->dream_fingerprint);
				return true;
			} else { return false; }
		}

		public function getDreamByTitle($title) {
			$dreamArray = array();
			$sql = "SELECT * FROM dreams WHERE dream_title=:uid;";
			$stmt = $this->dorkodiaDB->sude($sql, array(':uid' => $title));
			if ($stmt->rowCount()) {
				while ($neuDream = $stmt->fetch(PDO::FETCH_ASSOC))
					array_push($dreamArray, $neuDream);
			} else { return false; }
			return $dreamArray;
		}

		public function getDreamByUserId($userID) {
			$dreamArray = array();
			$sql = "SELECT * FROM dreams WHERE dream_userID=:uid;";
			$stmt = $this->dorkodiaDB->sude($sql, array(':uid' => $userID));
			if ($stmt->rowCount()) {
				while ($neuDream = $stmt->fetch(PDO::FETCH_ASSOC))
					array_push($dreamArray, $neuDream);
			} else { return false; }
			return $dreamArray;
		}

		public function getDreamByIsReached($userID = NULL, $isReached) {
			$dreamArray = array();
			switch ($isReached) {
				case true:
					$isReached = 1;
					break;
				case false:
					$isReached = 0;
					break;
			}
			if(empty($userID)) {
				$sql = "SELECT * FROM dreams WHERE dream_isReached=:type;";
				$stmt = $this->dorkodiaDB->sude($sql, array(':type' => $isReached));
			} elseif(is_integer($userID) && ($userID > 0)) {
				$sql = "SELECT * FROM dreams WHERE dream_isReached=:type AND dream_userID=:uid;";
				$stmt = $this->dorkodiaDB->sude($sql, array(':type' => $isReached, ':uid' => $userID));
			} else {
				return false;
			}
			if ($stmt->rowCount()) {
				while ($neuDream = $stmt->fetch(PDO::FETCH_ASSOC))
					array_push($dreamArray, $neuDream);
			} else { return false; }
			return $dreamArray;
		}

		public function giveupDream($dreamID = NULL)
		{
			if(empty($dreamID)) {
				if (!empty($this->getDreamId())) {
					return $this->deleteDream();
				} else {
					return false;
				}
			} elseif (is_integer($dreamID) && $dreamID > 0) {
				$temp = new self();
				$temp->getDreamById($dreamID);
				return $temp->deleteDream();
			}
		}

		public function reachDream()
		{
			$dID = $this->getDreamId();
			if (!empty($dID)) {
				$sql = "UPDATE dreams SET dream_isReached=1 WHERE dream_id=:did";
				$stmt = $this->dorkodiaDB->sude($sql, array(':did' => $dID));
				return true;
			} else {
				return false;
			}
		}
	}
?>
