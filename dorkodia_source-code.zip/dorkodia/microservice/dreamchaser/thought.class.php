<?php
	require_once DB_DIR."/dorkodia-db.microservice.php";
	class Thought {
		protected $thoughtID;
		protected $userID;
		protected $content;
		protected $timestamp;
		protected $fingerprint;

		//internal responsible db connection
		protected $dorkodiaDB;

		public function __construct() {
			$this->dorkodiaDB = new DorkodiaDB();
		}

		public function setThought($thought_id = NULL, $user_id, $content, $timestamp = NULL, $fingerprint) {
			if(!empty($user_id) && !empty($content) && !empty($fingerprint)) {
				if(empty($timestamp)) {
					$this->timestamp = date('d.m.Y H:i:s');
				} else {
					$this->timestamp = $timestamp;
				} if(!empty($thought_id)) {
					$this->thoughtID = $thought_id;
				}
				$this->userID = $user_id;
				$this->content = $content;
				$this->fingerprint = $fingerprint;
				return true;
			} else {
				return false;
			}
		}
		//getters
		public function getThoughtId() {
			return $this->thoughtID;
		}

		public function getUserId() {
			return $this->userID;
		}

		public function getContent() {
			return $this->content;
		}

		public function getTimestamp() {
			return $this->timestamp;
		}

		public function getFingerprint() {
			return $this->fingerprint;
		}

		public function getThoughtByArray($array) {
			if (isset($array['thought_id']) && isset($array['thought_userID']) && isset($array['thought_content']) && isset($array['thought_timestamp']) && isset($array['thought_fingerprint'])) {
				if (!empty($array['thought_id']) && !empty($array['thought_userID']) && !empty($array['thought_content']) && !empty($array['thought_timestamp']) && !empty($array['thought_fingerprint'])) {
					$this->setThought($array['thought_id'], $array['thought_userID'], $array['thought_content'], $array['thought_timestamp'], $array['thought_fingerprint']);
				} else {
					return false;
				}
			} else {
				return false;
			}
		}

		public function getStatus($userID) {
			$sql = "SELECT * FROM thoughts WHERE thought_userID=:uid ORDER BY thought_timestamp DESC LIMIT 1;";
			$stmt = $this->dorkodiaDB->sude($sql, array(':uid' => $userID));
			if ($stmt->rowCount()) {
				while ($neuThought = $stmt->fetch(PDO::FETCH_OBJ))
					$this->setThought($neuThought->thought_id, $neuThought->thought_userID, $neuThought->thought_content, $neuThought->thought_timestamp, $neuThought->thought_fingerprint);
				return true;
			} else { return false; }
		}

		public function isThoughtEmpty() {
			if(empty($this->getThoughtId()) || empty($this->getUserId()) || empty($this->getTimestamp()) || empty($this->getContent()) || empty($this->getFingerprint())) {
				return true;
			} else {
				return false;
			}
		}

		public function saveThought() {
			if(!empty($this->getUserId()) && !empty($this->getContent())  && !empty($this->getFingerprint())) {
				try {
					$sql = "INSERT INTO thoughts (thought_userID, thought_content, thought_fingerprint) VALUES ('{$this->getUserId()}', '{$this->getContent()}', '{$this->getFingerprint()}');";
					$retVal = $this->dorkodiaDB->query($sql);
					$this->getThoughtByArray($this->getThoughtByFingerprint($this->getFingerprint()));
					return $this;
				} catch(Exception $e) {
					return false;
				}
			} else {
				return false;
			}
		}

		public function deleteThought() {
			try {
				$sql = "DELETE FROM thoughts WHERE thought_id='{$this->getThoughtId()}' AND thought_fingerprint='{$this->getFingerprint()}';";
				return $this->dorkodiaDB->query($sql);
			} catch(Exception $excpt) {
				return false;
			}
		}

		public function deleteUserBrain($userID) {
			try {
				$sql = "DELETE FROM thoughts WHERE thought_userID='$userID';";
				return $this->dorkodiaDB->query($sql);
			} catch(Exception $excpt) {
				return false;
			}
		}

		public function getThoughtById($thoughtID) {
			$sql = "SELECT * FROM thoughts WHERE thought_id=:tid LIMIT 1;";
			$stmt = $this->dorkodiaDB->sude($sql, array(':tid' => $thoughtID));
			if ($stmt->rowCount()) {
				while ($neuThought = $stmt->fetch(PDO::FETCH_OBJ))
					$this->setThought($neuThought->thought_id, $neuThought->thought_userID, $neuThought->thought_content, $neuThought->thought_timestamp, $neuThought->thought_fingerprint);
				return true;
			} else { return false; }
		}

		public function getThoughtByFingerprint($fingerprint) {
			$sql = "SELECT * FROM thoughts WHERE thought_fingerprint=:f;";
			$stmt = $this->dorkodiaDB->sude($sql, array(':f' => $fingerprint));
			if ($stmt->rowCount()) {
				while ($neuThought = $stmt->fetch(PDO::FETCH_OBJ))
					$this->setThought($neuThought->thought_id, $neuThought->thought_userID, $neuThought->thought_content, $neuThought->thought_timestamp, $neuThought->thought_fingerprint);
				return true;
			} else { return false; }
		}

		public function getThoughtByUserId($userID) {
			$ideaArray = array();
			$sql = "SELECT * FROM thoughts WHERE thought_userID=:uid;";
			$stmt = $this->dorkodiaDB->sude($sql, array(':uid' => $userID));
			if ($stmt->rowCount()) {
				while ($neuThought = $stmt->fetch(PDO::FETCH_ASSOC))
					array_push($ideaArray, $neuThought);
			} else { return false; }
			return $ideaArray;
		}

		public function searchThought($q, $userID) {
			$ideaArray = array();
			$sql = "SELECT * FROM thoughts WHERE thought_userID=:uid AND thought_content LIKE '%$q%';";
			$stmt = $this->dorkodiaDB->sude($sql, array(':uid'=>$userID));
			if ($stmt->rowCount()) {
				while ($neuThought = $stmt->fetch(PDO::FETCH_ASSOC))
					array_push($ideaArray, $neuThought);
			} else { return false; }
			return $ideaArray;
		}
	}
?>
