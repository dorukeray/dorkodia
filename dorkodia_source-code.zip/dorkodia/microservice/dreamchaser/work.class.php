<?php
//Dorkodia work class
	class Work {
		public $workID;
		public $title;
		public $explanation;
		public $attachmentURL;
		public $timestamp;
		public $dreamID;
		


	}
?>
