<?php
	//Dorkodia note class
	require_once DB_DIR."/dorkodia-db.microservice.php";

	class Note {
		protected $noteID;
		protected $userID;
		protected $timestamp;
		protected $title;
		protected $content;
		protected $fingerprint;

		//db
		protected $dorkodiaDB;

		public function __construct() {
			$this->dorkodiaDB = new DorkodiaDB();
		}

		public function setNote($id = NULL, $whom, $timestamp, $title, $content, $fingerprint) {
			if(!empty($whom) && !empty($title) && !empty($content) && !empty($fingerprint)) {
				if(empty($timestamp)) {
					$this->timestamp = date('Y.m.d H:i:s');
				} else {
					$this->timestamp = $timestamp;
				} if(!empty($id)) {
					$this->noteID = $id;
				}
				$this->userID = $whom;
				$this->title = $title;
				$this->content = $content;
				$this->fingerprint = $fingerprint;
			} else {
				return false;
			}
		}

		public function getNoteId() {
			return $this->noteID;
		}

		public function getUserId() {
			return $this->userID;
		}

		public function getTitle() {
			return $this->title;
		}

		public function getContent() {
			return $this->content;
		}

		public function getCreateTime() {
			return $this->timestamp;
		}

		public function getFingerprint() {
			return $this->fingerprint;
		}

		public function getNoteByArray($array)
		{
			if (isset($array['note_id']) && isset($array['note_userID']) && isset($array['note_createTime']) && isset($array['note_title']) && isset($array['note_content']) && isset($array['note_fingerprint'])) {
				if(!empty($array['note_id']) && !empty($array['note_userID']) && !empty($array['note_createTime']) && !empty($array['note_title']) && !empty($array['note_content']) && !empty($array['note_fingerprint'])) {
					$this->setNote($array['note_id'], $array['note_userID'], $array['note_createTime'], $array['note_title'], $array['note_content'], $array['note_fingerprint']);
				} else {
					return false;
				}
			} else {
				return false;
			}
		}

		public function getNoteById($noteID) {
			$sql = "SELECT * FROM notes WHERE note_id=:nid LIMIT 1;";
			$stmt = $this->dorkodiaDB->sude($sql, array(':nid' => $noteID));
			if ($stmt->rowCount()) {
				while ($neuNote = $stmt->fetch(PDO::FETCH_OBJ))
					$this->setNote($neuNote->note_id, $neuNote->note_userID, $neuNote->note_createTime, $neuNote->note_title, $neuNote->note_content, $neuNote->note_fingerprint);
				return true;
			} else { return false; }
		}

		public function getNoteByFingerprint($fingerprint) {
			$sql = "SELECT * FROM notes WHERE note_fingerprint=:nid LIMIT 1;";
			$stmt = $this->dorkodiaDB->sude($sql, array(':nid' => $fingerprint));
			if ($stmt->rowCount()) {
				while ($neuNote = $stmt->fetch(PDO::FETCH_OBJ))
					$this->setNote($neuNote->note_id, $neuNote->note_userID, $neuNote->note_createTime, $neuNote->note_title, $neuNote->note_content, $neuNote->note_fingerprint);
				return true;
			} else { return false; }
		}

		public function getNoteByUserId($userID) {
			$noteArray = array();
			$sql = "SELECT * FROM notes WHERE note_userID=:uid;";
			$stmt = $this->dorkodiaDB->sude($sql, array(':uid' => $userID));
			if ($stmt->rowCount()) {
				while ($neuNote = $stmt->fetch(PDO::FETCH_ASSOC))
					array_push($noteArray, $neuNote);
			} else { return false; }
			return $noteArray;
		}

		public function getNoteByTitle($noteTitle) {
			$noteArray = array();
			$sql = "SELECT * FROM notes WHERE note_title=:tit;";
			$stmt = $this->dorkodiaDB->sude($sql, array(':tit' => $noteTitle));
			if ($stmt->rowCount()) {
				while ($neuNote = $stmt->fetch(PDO::FETCH_ASSOC))
					array_push($noteArray, $neuNote);
			} else { return false; }
			return $noteArray;
		}

		public function isNoteEmpty() {
			if(empty($this->getNoteId()) || empty($this->getUserId()) || empty($this->getCreateTime()) || empty($this->getTitle()) || empty($this->getContent()) || empty($this->getFingerprint())) {
				return true;
			} else {
				return false;
			}
		}

		public function takeNote() {
			if(!empty($this->getUserId()) && !empty($this->getTitle()) && !empty($this->getContent()) && !empty($this->getFingerprint())) {
					$sql = "INSERT INTO notes (note_userID, note_title, note_content, note_fingerprint) VALUES ('{$this->getUserId()}', '{$this->getTitle()}', '{$this->getContent()}', '{$this->getFingerprint()}');";
					$this->dorkodiaDB->query($sql);
					$this->getNoteByArray($this->getNoteByFingerprint($this->getFingerprint()));
					return $this;
			} else {
				return false;
			}
		}

		public function deleteUserNotes($userID) {
			try {
				$sql = "DELETE FROM notes WHERE note_userID='$userID';";
				return $this->dorkodiaDB->query($sql);
			} catch(Exception $excpt) {
				return false;
			}
		}

		public function trashNote() {
			try {
				$sql = "DELETE FROM notes WHERE note_id='{$this->getNoteID()}' AND note_fingerprint='{$this->getFingerprint()}';";
				return $this->dorkodiaDB->query($sql);
			} catch(Exception $excpt) {
				return false;
			}
		}

		public function searchNote($q, $userID)
		{
			$noteArray = array();
			$sql = "SELECT * FROM notes WHERE note_userID=:uid AND (note_title LIKE '%$q%' OR note_content LIKE '%$q%');";
			$stmt = $this->dorkodiaDB->sude($sql, array(':uid'=>$userID));
			if ($stmt->rowCount()) {
				while ($neuNote = $stmt->fetch(PDO::FETCH_ASSOC))
					array_push($noteArray, $neuNote);
			} else { return false; }
			return $noteArray;
		}
	}
?>
