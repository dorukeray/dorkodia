<?php
	require_once DB_DIR."/dorkodia-db.microservice.php";
	class Activity {
		protected $activityID;
		protected $type;
		protected $userID;
		protected $timestamp;
		protected $thingID;

		protected $dorkodiaDB;

		//possible activity types (for NOW): DREAM, WORK, THOUGHT, NOTE, BLOG

		public function __construct() {
			$this->dorkodiaDB = new DorkodiaDB();
		}

		public function setActivity($activity_id = NULL, $typer, $user_id, $timestamp = NULL, $thing_id) {
			if(!empty($user_id) && !empty($thing_id) && !empty($typer)) {
				if(empty($timestamp)) {
					$this->timestamp = date('Y.m.d H:i:s');
				} else {
					$this->timestamp = $timestamp;
				}
				if(!empty($activity_id)) {
					$this->activityID = $activity_id;
				}
				$this->userID = $user_id;
				$this->thingID = $thing_id;
				$this->type = $typer;
			} else {
				return false;
			}
		}

		//getter setter
		public function getActivityId() {
			return $this->activityID;
		}

		public function getType() {
			return $this->type;
		}

		public function getUserId() {
			return $this->userID;
		}

		public function getTimestamp() {
			return $this->timestamp;
		}

		public function getThingId() {
			return $this->thingID;
		}

		public function getActivityByArray($array) {
			if (isset($array['activity_id']) && isset($array['activity_type']) && isset($array['activity_userID']) && isset($array['activity_timestamp']) && isset($array['activity_thingID'])) {
				$this->setActivity($array['activity_id'], $array['activity_type'], $array['activity_userID'], $array['activity_timestamp'], $array['activity_thingID']);
			} else {
				return false;
			}
		}

		public function isActivityEmpty() {
			if(empty($this->getActivityId()) || empty($this->getUserId()) || empty($this->getTimestamp()) || empty($this->getType()) || empty($this->getThingId())) {
				return true;
			} else {
				return false;
			}
		}

		public function saveActivity() {
			if(!empty($this->getThingId()) && !empty($this->getUserId()) && !empty($this->getType())) {
					$sql = "INSERT INTO activity (activity_userID, activity_type, activity_thingID) VALUES ('{$this->getUserId()}', '{$this->getType()}',  '{$this->getThingId()}');";
					$retVal = $this->dorkodiaDB->query($sql);
					return $retVal;
			} else {
				return false;
			}
		}

		public function deleteActivity() {
			try {
				$sql = "DELETE FROM activity WHERE activity_id='{$this->getActivityId()}';";
				return $this->dorkodiaDB->query($sql);
			} catch(Exception $excpt) {
				return false;
			}
		}

		public function deleteUserActivity($userID) {
			try {
				$sql = "DELETE FROM activity WHERE activity_userID=$userID;";
				return $this->dorkodiaDB->query($sql);
			} catch(Exception $excpt) {
				return false;
			}
		}

		public function getActivityById($activityID) {
			$sql = "SELECT * FROM activity WHERE activity_id=:aid LIMIT 1;";
			$stmt = $this->dorkodiaDB->sude($sql, array(':aid' => $activityID));
			if ($stmt->rowCount()) {
				while ($neuActivity = $stmt->fetch(PDO::FETCH_OBJ))
					$this->setActivity($neuActivity->activity_id, $neuActivity->activity_type, $neuActivity->activity_userID, $neuActivity->activity_timestamp, $neuActivity->activity_thingID);
				return true;
			} else { return false; }
		}

		public function getActivityByThingId($type, $thingID) {
			$sql = "SELECT * FROM activity WHERE activity_thingID=:tid AND activity_type=:type LIMIT 1;";
			$stmt = $this->dorkodiaDB->sude($sql, array(':tid' => $thingID, ':type' => $type));
			if ($stmt->rowCount()) {
				while ($neuActivity = $stmt->fetch(PDO::FETCH_OBJ))
					$this->setActivity($neuActivity->activity_id, $neuActivity->activity_type, $neuActivity->activity_userID, $neuActivity->activity_timestamp, $neuActivity->activity_thingID);
				return true;
			} else { return false; }
		}

		public function getActivityByUserId($userID, $DESC) {
			$actArray = array();
			if ($DESC == true) {
				$sql = "SELECT * FROM activity WHERE activity_userID=:uid ORDER BY activity_timestamp DESC;";
			} else {
				$sql = "SELECT * FROM activity WHERE activity_userID=:uid ORDER BY activity_timestamp ASC;";
			}
			$stmt = $this->dorkodiaDB->sude($sql, array(':uid' => $userID));
			if ($stmt->rowCount()) {
				while ($neuActivity = $stmt->fetch(PDO::FETCH_ASSOC))
					array_push($actArray, $neuActivity);
			} else { return false; }
			return $actArray;
		}

		public function getActivityByType($type) {
			$actArray = array();
			$sql = "SELECT * FROM activity WHERE activity_type=:type;";
			$stmt = $this->dorkodiaDB->sude($sql, array(':type' => $type));
			if ($stmt->rowCount()) {
				while ($neuActivity = $stmt->fetch(PDO::FETCH_ASSOC))
					array_push($actArray, $neuActivity);
			} else { return false; }
			return $actArray;
		}
	}
?>
