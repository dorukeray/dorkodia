<?php
//Dorkodia blog class
	class Blog {
		public $entryID;
		public $userID;
		public $timestamp;
		public $title;
		public $content;
		public $hit;
		
		
		
	}
?>
