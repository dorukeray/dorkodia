<?php
	//Dorkodia dreamchaser microservice
	//required classes for this microservice
	require_once "dream.class.php";
	require_once "activity.class.php";
	require_once "note.class.php";
	require_once "thought.class.php";
	//required microservices for this microservice
	require_once DB_DIR."/dorkodia-db.microservice.php";
	require_once USER_DIR."/user.microservice.php";

	class DreamChaser {
		//şimdilik boş
	}

?>
