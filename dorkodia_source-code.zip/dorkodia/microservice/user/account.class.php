<?php
//Dorkodia account class
	class Account {
		public $accountID;
		public $userID;
		public $createTimestamp;
		public $secureToken;
		
		
		
	}
