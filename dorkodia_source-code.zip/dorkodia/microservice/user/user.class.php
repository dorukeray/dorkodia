<?php
	//Dorkodia User class
	class User {
		protected $userID;
		protected $accountID; //şimdilik işlevsiz, sosyal ağ özelliğiyle aktif olacak.
		protected $userName;
		protected $fullName;
		protected $hashedPass;
		protected $email;

		public function setUser($userid, $username, $fullname, $hashedpass, $email) {
			$this->userID = $userid;
			#$this->accountID = $accountid;
			$this->hashedPass = $hashedpass;
			$this->userName = $username;
			$this->fullName = $fullname;
			$this->email = $email;
		}

		//buff mage thingy.
		public function isThisAnyKindOfHollowPerson() {
			if(empty($this->userID) || empty($this->userName) || empty($this->fullName) || empty($this->email))
				return true;
			else
				return false;
		}

		public function getID() {
			return $this->userID;
		}

		public function getHashedPass() {
			return $this->hashedPass;
		}

		public function getUsername() {
			return $this->userName;
		}

		public function getEmail() {
			return $this->email;
		}

		public function getFullName() {
			return $this->fullName;
		}

		public function getAccountID() {
			return $this->accountID;
		}
	}
?>
