<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneleri
?>
<!DOCTYPE html>
<html lang="tr" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Gizlilik - Dorkodia</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="shortcut icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
  </head>
  <body>
    <div id="book">
      <?php require_once "./req/header.php"; ?>
      <div id="pod">
        <?php require_once "./req/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1>Gizlilik</h1>
        </div>
        <div id="content">
          <div class="column base-column">
            <div class="set">
              <h2>Dorkodia Nedir?</h2>
              <p>Merhaba. Dorkodia'ya hoş geldin. Dorkodia insanların fikir ve hayallerini paylaşabilecekleri, üstünde çalışabilecekleri ve onları gerçekleştirebilecekleri bir platformdur.</p>
              <p></p>
              <a href="#">Buraya tıklayın<i class="icon d-external-link"></i></a>
              <p>Bu bir paragraf.</p>
              <img src="./image/welcome_3.gif" class="small-image">
              <img src="./image/banners/mark.jpg" class="medium-image">
              <img src="file://media/dorkodu/3EE4E200E4E1B9F31/Users/Dorkodu/indir.png" class="large-image">
            </div>
          </div>
          <div class="column nav-column">
            <div class="set synapse">
              <h3>Kurucu</h3>
              <ul>
                <li><p>Doruk Dorkodu - Yazılım Mimarı ve   Tasarımcı</p></li>
              </ul>
            </div>
            <div class="set synapse">
              <h3>Eşsiz ufuklar</h3>
              <p>Dorkodu ve ideallerimiz hakkında bilgi edin</p>
            </div>
            <div class="set synapse">
              <h3>Fibula</h3>
              <p>Dorkodu'daki son konuşulanlar için; bilim, sanat ve kültür hakkında; Fibula'ya göz at.</p>
            </div>
          </div>
        </div>
      </div>
      <?php require_once "./req/footer.php" ?>
    </div>
  </body>
</html>
