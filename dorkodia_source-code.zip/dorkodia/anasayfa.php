<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneleri
	if(!$isLoggedIn) {
		$dorAuth->redirectForLogin($dorkodia->getCurrentDocument());
	} elseif($isLoggedIn) {
		$currentUserFirstName = explode(' ', $currentUser->getFullName())[0];
		$currentUserID = $currentUser->getID();
		$dorkodia->connectToDreamchaserService();
		$activityReporter = new Activity();
		$dreamRequester = new Dream();
		if (isset($_POST['post-status'])) {
			$statusText = addslashes(htmlspecialchars($_POST['status-input']));
			if (!empty($statusText)) {
				$idea = new Thought();
				$fingerprint = $dorAuth->dorcrypted->generateUniqToken(32, RANDOM_BYTES);
				$idea->setThought(NULL, $currentUserID, $statusText, NULL, $fingerprint);
				$saveResult = $idea->saveThought();
				$activityReporter->setActivity(NULL, "THOUGHT", $currentUserID, NULL, $idea->getThoughtId());
				$reportResult = $activityReporter->saveActivity();

				if($saveResult && $reportResult) {
					$resultBox = "<div class='message-box info'>
										<h2>Oow kimler gelmiş...</h2>
										<p>Düşünce akışın başarıyla güncellendi. Böyle devam et, aferin.</p>
										</div>";
				} elseif(!$saveResult && !$reportResult) {
					$resultBox = "<div class='message-box error'>
										<h2>Hata</h2>
										<p>Bir hata oluştu. Durumun güncellenemedi.</p>
										</div>";
				} elseif(!$reportResult) {
					$resultBox = "<div class='message-box warning'>
										<h2>Söylemekten Utanıyoruz Ama...</h2>
										<p>Bir hata oluştu. Durumun güncellendi ancak bu sonsuza kadar böyle sürmeyebilir.</p>
										</div>";
				} elseif(!$saveResult) {
					$resultBox = "<div class='message-box warning'>
										<h2>Söylemekten Utanıyoruz Ama...</h2>
										<p>İlginç bir sey oldu ve... Durumun güncellenemedi.</p>
										</div>";
				}
			} else {
				$resultBox = "<div class='message-box warning'>
												<h2>Uyarı</h2>
												<p>Bak, burada oyun oynamıyoruz. Lütfen boş yapma. Ciddiyim.</p>
											</div>";
			}
		}
		//dreamfeed
		$userDreams = $dreamRequester->getDreamByIsReached($currentUserID, false);
		$feedElements = $activityReporter->getActivityByUserId($currentUserID, true);
	}
?>

<!DOCTYPE html>
<html lang="tr" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Anasayfa - Dorkodia</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="shortcut icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
  </head>
  <body>
    <div id="book">
      <?php require_once "./req/header.php"; ?>
      <div id="pod">
			<?php require_once "./req/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1>Merhaba <?php echo $currentUserFirstName; ?>!</h1>
        </div>
        <div id="content">
          <div class="column base-column">
            <div class="set" id="dreamwall">
            <?php require_once REQ_DIR."/error-handler.php"; ?>
              <h2>Hayal Duvarı</h2>
							<?php if(!empty($resultBox)) echo $resultBox;?>
              <div class="dreamwall-share-box">
                <form action="<?php echo $dorkodia->getCurrentDocument(); ?>" method="POST">
                  <label for="status-input">Düşünce akışına bir şeyler yaz :</label>
                  <textarea name="status-input" id="status-input" class="input-richtext" autocomplete="off"></textarea>
                  <button type="submit" name="post-status" id="post-status" class="input-submit" maxlength="256">yolla!</button>
                </form>
              </div>
              <div class="dreamwall-my-dreamlist">
                <div class="header-set">
                  <h3>Hayallerim</h3>
                  <a href="hayal.php">düzenle</a>
                </div>
                <div class="dlist-content">
                  <ul>
										<?php
										if (is_array($userDreams) && (count($userDreams) > 0)) {
											foreach ($userDreams as $userDream) {
												$tmpDream = new Dream();
												$tmpDream->getDreamByArray($userDream);
												echo '<li onclick="javascript:window.location.href=\'hayal.php\';"><i class="icon d-food-ice-cream-streamline"></i><p>'.$tmpDream->getTitle().'</p><a href="hayal.php"><i class="icon d-caret-right end"></i></a></li>';
											}
										} elseif (!$userDreams) {
											echo "<p style='width:95%; margin:10px auto;'>Zihnin bu aralar boş görünüyor. Yeni bir hayalin peşine düşmenin zamanı gelmedi mi sence?</p>";
										}
										?>
									</ul>
                </div>
              </div>
							<?php
								if (is_array($feedElements) && (count($feedElements) > 0)) {
									$dream = new Dream();
									$note = new Note();
									$thought = new Thought();
									foreach ($feedElements as $feedElement) {
										$activity = new Activity();
										$activity->getActivityByArray($feedElement);
										switch ($activity->getType()) {
											case 'DREAM':
												$dream->getDreamById($activity->getThingId());
												echo '<div class="post do-dream">
							                <div class="icon d-cloud-2"></div>
							                <div class="post-body">
							                  <div class="post-info">
							                    <p class="p-info-username">'.$currentUser->getUsername().'</p><p class="p-info-timestamp">'.$dream->getTimestamp().'</p>
							                  </div>
							                  <div class="post-content">
							                    <h5><span>yeni bir hayalin peşine düştü &bull; </span>'.$dream->getTitle().'</h5>
							                    <p>'.$dream->getExplanation().'</p>
							                  </div>
							                </div>
							              </div>';
												break;
											case 'NOTE':
												$note->getNoteById($activity->getThingId());
												echo '<div class="post do-note">
															<div class="icon d-script"></div>
															<div class="post-body">
																<div class="post-info">
																	<p class="p-info-username">'.$currentUser->getUsername().'</p><p class="p-info-timestamp">'.$note->getCreateTime().'</p>
																</div>
																<div class="post-content">
																	<h5><span>yeni bir hayalin peşine düştü &bull; </span>'.$note->getTitle().'</h5>
																	<p>'.$note->getContent().'</p>
																</div>
															</div>
														</div>';
												break;
											case 'THOUGHT':
												$thought->getThoughtById($activity->getThingId());
												echo '<div class="post do-think">
					                <div class="icon d-quote"></div>
					                <div class="post-body">
					                  <div class="post-info">
					                    <img src="" class="user-photo">
					                    <p class="p-info-username">'.$currentUser->getUsername().'</p><p class="p-info-timestamp">'.$thought->getTimestamp().'</p>
					                  </div>
					                  <div class="post-content">
					                    <h5><span>durumunu güncelledi &bull; </span>Düşünce Akışı</h5>
					                    <p>'.$thought->getContent().'</p>
					                  </div>
					                </div>
					              </div>';
												break;
										}
									}
								} elseif (!$feedElements) {
									echo "<p style='width:95%; margin:10px auto;'>Hayal akışında gösterecek bir şey yok.</p>";
								}
							?>

              <!--<div class="post do-work">
                <div class="icon d-bulb"></div>
                <div class="post-body">
                  <div class="post-info">
                    <img src="" class="user-photo">
                    <p class="p-info-username">dorkodu</p><p class="p-info-timestamp">04.02.2004 11:06</p>
                  </div>
                  <div class="post-content">
                    <h5><span>yeni bir çalışma ekledi &bull; </span>Dorkodia için yeni dokümanlar.</h5>
                    <p>Dorkodia hakkında, sss ve yardım sayfalarının use-case diyagramları.</p>
                  </div>
                </div>
              </div>
              <div class="post do-note">
                <div class="icon d-script"></div>
                <div class="post-body">
                  <div class="post-info">
                    <img src="" class="user-photo">
                    <p class="p-info-username">dorkodu</p><p class="p-info-timestamp">04.02.2004 11:06</p>
                  </div>
                  <div class="post-content">
                    <h5><span>yeni bir not ekledi &bull; </span>dorkodia nasıl mı gidiyor?</h5>
                    <p>tek kelimeyle mükemmel. daha iyi olamazdı :D</p>
                  </div>
                </div>
              </div>

              <div class="post do-blog">
                <div class="icon d-book-1"></div>
                <div class="post-body">
                  <div class="post-info">
                    <img src="" class="user-photo">
                    <p class="p-info-username">dorkodu</p><p class="p-info-timestamp">04.02.2004 11:06</p>
                  </div>
                  <div class="post-content">
                    <h5><span>yeni bir günce yazdı &bull; </span>Nasıl bir güvenlik katmanı ekledim?</h5>
                    <p>Bugün konumuz biraz farklı. Aslında ...<a href="#">devamını oku</a> </p>
                  </div>
                </div>
              </div>
              <div class="post do-notify">
                <div class="icon d-megaphone"></div>
                <div class="post-body">
                  <div class="post-info">
                    <img src="" class="user-photo">
                    <p class="p-info-username">Dorkodia</p><p class="p-info-timestamp">04.02.2004 11:06</p>
                  </div>
                  <div class="post-content">
                    <h5><span>bildirim &bull; </span>Doruk, hayallerini takip etmeyi unutma!</h5>
                    <p>Merhaba. Üç hayalin gerçekleşmeyi bekliyor.</p>
                  </div>
                </div>
              </div>-->
            </div>
          </div>
          <div class="column nav-column">
				<?php require_once REQ_DIR.'/nanofeed.php'; ?>
          </div>
        </div>
      </div>
      <?php require_once "./req/footer.php" ?>
    </div>
  </body>
</html>
