<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneleri
	if(!$isLoggedIn) {
		$dorAuth->redirectForLogin($dorkodia->getCurrentDocument());
	}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Biri - Dorkodia</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="shortcut icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
  </head>
  <body>
    <div id="book">
           <?php require_once "./req/header.php"; ?>
      <div id="pod">
        <?php require_once "./req/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1>Biri - Doruk Dorkodu</h1>
        </div>
        <div id="content" class="intro">
          <div class="column base-column">
              <div class="biri-set">
                <div class="biri-photo-column">
                  <div class="biri-photo-box">
                    <img src="./image/banners/panda.jpeg" alt="Dorkodu'nun Fotoğrafı">
                  </div>
                  <div class="biri-photo-column-nav">
                    <ul>
                      <li><a href="#">Doruk · Hayal Duvarına Bak</a></li>
											<li><a href="#">Doruk · Notlarını Oku</a></li>
											<li><a href="#">Doruk · Bir İleti Gönder</a></li>
											<li><a href="#">Doruk · Yer İmlerini Göster</a></li>
											<li><a href="#">Doruk · Bu Birisini $ikayet Et</a></li>
                    </ul>
                  </div>
                  <div class="biri-photo-column-status">
                    <div class="header-set">
                      <h3>Durum</h3>
                    </div>
                    <div class="biri-status-box">
											<p class="biri-status-general">
												<i class='icon d-'></i> Doruk $u an çevrimiçi.</p>
											</p>
                      <p class="biri-status-content">
												<i class='icon d-quote'></i> Dorkodia'yı bitirdim <span style="color:var(--dorkodia-label); font-weight:normal;"> &bull; 13:45</span></p>
											</p>
                    </div>
                  </div>
                </div>
                <div class="biri-know-column">
                  <div class="biri-std-know">
										<h2>Doruk Eray <span class="biri-username">· dorkodu</span></h2>
										<ul>
											<li><p>Dorkodu Inc. 	</p></li>
											<li><p>Boğaziçi Bilgisayar Mühendisliği</p></li>
											<li><p>İstanbul, TR</p></li>
										</ul>
                  </div>
                  <div class="biri-detail-know">

                  </div>
                  <div class="biri-nanofeed">

                  </div>
                  <div class="biri-personal-know">

                  </div>
                </div>
              </div>
							<!--<div class="message-box info">
								<h3>Bu özellik henüz etkin değil.</h3>
								<p>Dorkodia'ya Sosyal Ağ özelliği eklenince buradan insanların hesaplarına ulaşabilirsin.</p>
							</div>-->
            </div>
        </div>
      </div>
      <?php require_once "./req/footer.php" ?>
    </div>
  </body>
</html>
