<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneleri
?>
<!DOCTYPE html>
<html lang="tr" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Doğal Reklam - Dorkodia</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="shortcut icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
    <style>
		table {
			border:1px solid #acc;
			margin:10px auto;
			border-radius:2px;
			width:90%;
		}
		table td {
			border-top:1px solid #bcc;
			border-right:1px solid #bcc;
			background-color:#f5fafa;
			padding:5px;
		}
    </style>
  </head>
  <body>
    <div id="book">
      <?php require_once "./req/header.php"; ?>
      <div id="pod">
        <?php require_once "./req/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1>Dorkodia'da Doğal Reklamlar</h1>
        </div>
        <div id="content" class="intro">
          <div class="column base-column">
            <div class="set intro">
					<div style="width:68%; float:left;">
						<h4 style="color:#333;">Doğal Reklamlar Derken?</h4>
						<p>Reklamın amacı nedir? Bilinirlik sağlamak ve bireyi eyleme geçirmek. O zaman neden 100 yıllık yolları deneyesiniz ki?
						Doğrudan bireye ve onun arzularına ulaşın. Topluluğa seslenin. Bir gereksinimi giderin.</p>
						<h4 style="color:#333;">Neden Bir Doğal Reklam Vereyim Ki?</h4>
						<p>
							<span style="font-family:Roboto; font-weight:bold;">Yöntem : </span>İstediğiniz yöntemle doğrudan kendi amacınıza ulaşın.
							<br><span style="font-family:Roboto; font-weight:bold;">Doğru İleti : </span>Hedef kitlenize uygun iletiler verin ve bilinirliğinizi artırın.
							<br><span style="font-family:Roboto; font-weight:bold;">Doğal Dil : </span>İnsana dokunun. Bireye onun çevresindekilerle ulaşın.
						</p>
						<h4 style="color:#333;">Doğal Reklam Yöntemleri</h4>
						<p>İlgi alanları, yaş, cinsiyet, istatistikler gibi verilere göre hedef kitlenizi ve yöntemlerinizi seçin.
						Sadece anahtar kelimeler girerek etkili reklam verin.</p>
						<p>
							<span style="font-family:Roboto; font-weight:bold;">Banner : </span> Görsel içerikli reklamlarınızı Footer (760x50) ve Pod (120x180) alanlarında dinamik olarak yayınlayın.
							<br><span style="font-family:Roboto; font-weight:bold;">Sponsorlu Hesap : </span>Bir marka, işletme, veya kişi için sayfa oluşturun. Etkinliğinizi başkalarının çok daha sık görecektir.
							<br><span style="font-family:Roboto; font-weight:bold;">Sponsorlu Gönderi : </span>Hedef kitlenizin akışında yer alacak içerik paylaşın.
							<br><span style="font-family:Roboto; font-weight:bold;">Kağıt Uçak : </span>Sanal el ilanları veya duyurular mı istiyorsunuz? <br><a href="./kagit-ucak.php">Göz atın</a>.
						</p>
						<table>
							<tr><td colspan="2" style="border:0"><h4>Doğal Reklam Yöntemleri ve Fiyatlandırması</h4></td></tr>
							<tr>
								<td rowspan="2">Banner (Footer) </td>
								<td><span style="font-family:Roboto; font-size:11px;">Haftalık :</span>  80TL</td>
							</tr>
							<tr>
								<td><span style="font-family:Roboto; font-size:11px;">1000 Gösterim İçin :</span>  60TL</td>								
							</tr>
							<tr>
								<td rowspan="2">Banner (Pod) </td>
								<td><span style="font-family:Roboto; font-size:11px;">Haftalık :</span>  60TL</td>
							</tr>
							<tr>
								<td><span style="font-family:Roboto; font-size:11px;">1000 Gösterim İçin :</span>  40TL</td>								
							</tr>
							<tr>
								<td>Sponsorlu Hesap</td><td>20 TL</td>
							</tr>
							<tr>
								<td>Sponsorlu Gönderi</td><td><span style="font-family:Roboto; font-size:11px;">1000 Gösterim İçin :</span> 5 TL</td>
							</tr>
							<tr>
								<td>Kağıt Uçak (<a href="./kagit-ucak.php">Bu nedir?</a>)</td><td>5 TL</td>
							</tr>
						</table>
					</div>	
					<img src="./image/sde/ikna-yontemleri-2.jpg" class="small-image">
            </div>
          </div>
        </div>
      </div>
      <?php require_once "./req/footer.php" ?>
    </div>
  </body>
</html>

