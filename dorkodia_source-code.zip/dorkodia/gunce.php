<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneleri
	if(!$isLoggedIn) {
		$dorAuth->redirectForLogin($dorkodia->getCurrentDocument());
	} else {
		$currentUserID = $currentUser->getID();
		$dorkodia->connectToDreamchaserService();
	}
?>
<!DOCTYPE html>
<html lang="tr" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Günce - Dorkodia</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="shortcut icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
  </head>
  <body>
    <div id="book">
        <?php require_once "./req/header.php"; ?>
      <div id="pod">
        <?php require_once "./req/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1>Güncem</h1>
        </div>
        <div id="content">
          <div class="column base-column">
						<?php require_once REQ_DIR."/error-handler.php"; ?>
            <div class="set" id="dreamwall">
              <h2>Günce</h2>
							<div class='message-box warning'>
								<h2>Günce Hizmeti Etkin Değil</h2>
								<p>Açık oturum sayısı az, bu sebeple olup biten pek şey yok.</p>
							</div>
							<p>Burası Günce. Burada olup bitenden haberdar olursun. Ayrıca kendi günlük yazılarını da yayınlayabilirsin.</p>
							<p>Unutma, her gün sadece bir yazı yayınlama hakkın var.</p>
							<ul>
								<li><span></span></li>
							</ul>
							<br>
							<div class="header-set">
								<h3>Olup bitenler</h3>
							</div>
							<p>Burada görebileceğin bir şey yok.</p>
              <!--<div class="dream-new-dream new-blog">
                <div class="header-set">
                  <h3>Günce yaz</h3>
                </div>
                <form name="form-new-blog" action="gunce.php" method="post">
                  <label for="blog-topic">Başlık :</label>
                  <input type="text" name="blog-topic" id="blog-topic" class="input-text" autocomplete="off">
                  <label for="blog-explanation">Metin :</label>
                  <textarea name="blog-explanation" id="blog-explanation" class="input-richtext" autocomplete="off" maxlength="2048" ></textarea>
                  <button type="submit" name="button" class="input-submit">Yayınla</button>
                </form>
              </div>
              <div class="dreamwall-my-worklist">
                <div class="header-set">
                  <h3>Yazdıklarım</h3>
                </div>
                <div class="wlist-content">
                  <ul>
                    <li class="current"><i class="icon d-book"></i><p>Dorkodia'yı nasıl geliştirdim?</p><a href="#"><i class="icon d-caret-right end"></i></a></li>
                    <div class="dream-details">
                      <div class="dream-details-box">
                        <p class="activity-info-text">Yazar : Doruk Dorkodu, 08.03.2004 11:04</p>
                        <p class="blog-context">Merhaba. Ben Doruk. <strong>Dorkodu</strong> ve <strong>Cyudebeam</strong>'ın yaratıcılarıyım. Kim miyim ben? Tutkulu bir programcı, tasarımcı ve girişimci. <strong>Amacım insanlığın bilgi mirasını korumak ve geliştirmek; onların buna ulaşmasını ve kullanmasını kolaylaştırmak ve Dünya üzerindeki herkese bu hakkı tanımak.</strong><br><br>Dorkodia'yı da yine benim gibiler için geliştirdim. Bir umudu olanlara, hayali olanlara ve onunla dünyayı değiştirebileceğini düşünecek kadar tutkulu olanlara.<br><br>Burada hayallerini kovalayabilir, durumunu gözden geçirebilir ve sonuçlarına hemen ulaşabilrisin. Dorkodia bunun için yaratıldı. <b>Notlar tut, proje yürüt, çalışmalar ekle, günce yaz, zamanını iyi kullan ve verimli çalış!</b></p>
                      </div>
                      <div class="dream-details-controlbox">
                        <button type="button" id="work-btn-giveup" name="blog-btn-giveup" class="input-submit">Kaldır</button>
                      </div>
                    </div>
                    <li><i class="icon d-book"></i><p>Kendi oyunumu geliştirmek</p><a href="#"><i class="icon d-caret-right end"></i></a></li>
                    <li><i class="icon d-book"></i><p>Dünya seyahatine çıkmak</p><a href="#"><i class="icon d-caret-right end"></i></a></li>
                  </ul>
                </div>
              </div>
              <div class="dream-">

              </div>-->
            </div>
          </div>
          <div class="column nav-column">
            <?php require_once REQ_DIR.'/nanofeed.php'; ?>
          </div>
        </div>
      </div>
      <?php require_once "./req/footer.php" ?>
    </div>
  </body>
</html>
