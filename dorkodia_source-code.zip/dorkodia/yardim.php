<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneleri
	$tabTitle = 'Yardım ve Destek';
	$tabContent = '<div id="project" class="halfwidth">
			 <h4>Girişim</h4>
			 <p>Dorkodia insanları hayallerine bağlayan bir araçtır.</p>
			 <p>Dorkodia, 20 Nisan 2020 Pazartesi günü dünyaya açıldı.</p>
			 <p>Yeterli gelmediyse, <a href="./hakkinda.php">hakkında</a> bağlantısını ziyaret edin.</p>
		  </div>
		  <div id="people" class="halfwidth">
			 <h4>İnsanlar</h4>
			 <p>Doruk Dorkodu <span class="job-title">Yaratıcı, Yazılım Mimarı.</span></p>
		  </div>';

	if(isset($_GET['tab'])) {
		if(!empty($_GET['tab'])) {
			$tab = $_GET['tab'];
			switch ($tab) {
				case 'destek':
					$tabTitle = 'Destek';
					$tabContent = '<ul>
						<h3>Başlarken</h3>
							<li><a href="javascript:toggleVisible(\'ans1\')">Dorkodia ne?</a></li>
							<div id="ans1" class="faq-box">
								 Dorkodia insanların fikir ve hayallerini paylaşabilecekleri, üstünde çalışabilecekleri ve onları gerçekleştirebilecekleri bir platformdur.
							</div>
							<li><a href="javascript:toggleVisible(\'ans2\')">Dorkodia\'yı neden kurdunuz?</a></li>
							<div id="ans2" class="faq-box">
					İnsanların hayallerine ulaşmasına yardım edecek bir platform yoktu. Bu konuda bir hayal takip uygulaması yapmak mantıklıydı.
							</div>
							<li><a href="javascript:toggleVisible(\'ans13\')">Hangi yazılım mimarisini kullanıyorsunuz?</a></li>
							<div id="ans13" class="faq-box">
					Meraklıysan, <a href="buldum.php">buralara</a> bir göz at ;)
							</div>
							<h3>Hayaller ve İdealler</h3>
							<li><a href="javascript:toggleVisible(\'ans3\')">Hayal Duvarı Ne?</a></li>
							<div id="ans3" class="faq-box">
					Hayal Duvarı, Sen ve senin hayallerin üstüne kurulu, ne olup bittiğini görebildiğin bir akış, ileride daha da gelişecek.
							</div>
							<li><a href="javascript:toggleVisible(\'ans4\')">Hayal Duvarında ne görüyorum?</a></li>
							<div id="ans4" class="faq-box">
					Son etkinliğini, şimdilik. Yaptıkların, son düşüncelerin, notların ve henüz ulaşamadığın hayallerin.
							</div>
							<li><a href="javascript:toggleVisible(\'ans5\')">Neden Notlarda, Düşüncelerde ve Hayallerde karakter sınırı var?</a></li>
							<div id="ans5" class="faq-box">
					Çünkü senden hayallerini, ideallerini, düşüncelerini ve zihninden geçen her şeyi müthiş sade ve anlamlı ifade etmeni istiyoruz. Böylece onları kafanda iyice netleştirebiliyorsun.
					<br>Bir diğer nedeni de sakladığımız bilgi miktarı arttıkça işimiz zorlaşıyor. Bu sürede herkese bu fırsatı tanımak için bunu yapmalıyız.
							</div>
							<h3>Dorkodia ve Hayal Takipçisi</h3>
							<li><a href="javascript:toggleVisible(\'ans6\')">Düşünce ne?</a></li>
							<div id="ans6" class="faq-box">
					Zihninden geçenleri, fikirlerini, o anki durumunu paylaşmak veya bir anı olarak saklamak için yazdığın şeyler.
							</div>
							<li><a href="javascript:toggleVisible(\'ans7\')">Düşünce Akışı ne?</a></li>
							<div id="ans7" class="faq-box">
					Düşüncelerini görebileceğin Hayal Duvarı\'n. Yeniden eskiye hepsini görebilirsin.
							</div>
							<li><a href="javascript:toggleVisible(\'ans8\')">Notlar ne?</a></li>
							<div id="ans8" class="faq-box">
					Aklına gelip de unutmak istemediğin veya bir kenarda dursun dediğin şeyleri yazabileceğin bir Dorkodia özelliği.
							</div>
							<li><a href="javascript:toggleVisible(\'ans9\')">Durum ile Düşüncenin ne farkı var?</a></li>
							<div id="ans9" class="faq-box">
					Durum, senin en güncel düşüncen. Aynı anda yalnızca tek bir durumun olabilir, ancak birden fazla düşüncen olabilir.
							</div>
							<li><a href="javascript:toggleVisible(\'ans10\')">Paylaştığım şeyleri sonradan düzenleyemez miyim?</a></li>
							<div id="ans10" class="faq-box">
					Hayır, ama gerekenleri düzelttikten sonra tekrar paylaşabilirsin.
							</div>
							<li><a href="javascript:toggleVisible(\'ans11\')">Neden sadece ben kullanıyorum?</a></li>
							<div id="ans11" class="faq-box">
					Hayır, aynı anda binlerce kişi kullanıyor olabilir. Ancak şimdilik birbirinizden haberdar olamıyorsunuz. İlk Dorkodia yeniliği bunun üzerine olacak.
							</div>
							<h3>Güvenlik ve Kullanıcı</h3>
							<li><a href="javascript:toggleVisible(\'ans12\')">Güvenlik düzeyi ne?</a></li>
							<div id="ans12" class="faq-box">
					Dorkodia, düşüncelerinin çalınmaması veya sen olumsuz bir durumla karşılaşma diye, ek bir güvenlik katmanına sahip.<br><br>
					Tüm kullanım için önce bu katmandan geçilir. Ancak bu yine de mükemmel olmayabilir. Mükemmellikten uzak olsa da şu anın ötesinde olduğu kesin.
							</div>
							<li><a href="javascript:toggleVisible(\'ans15\')">Parolamı değiştirmek istiyorum. Ne yapacağım?</a></li>
							<div id="ans15" class="faq-box">
					Parolanı değiştirmek için Hesabım sayfasına bir bak.
							</div>
							<li><a href="javascript:toggleVisible(\'ans14\')">Parolamı unuttum, değiştiremez miyim?</a></li>
							<div id="ans14" class="faq-box">
					Ne yazık ki hayır. Güvenlik kaygılarımız sebebiyle bu şu an (20.04.2020 tarihi ile) mümkün değil. İstersen yeni bir hesap açabilirsin.
							</div>
						</ul>';
					break;
				case 'guvenlik':
					$tabTitle = 'Güvenlik';
					$tabContent = '<h2>Dorkodia\'da Güvenlik</h2>
					<p>Dorkodia geliştirilirken güvenlik katmanlı bir yapıda, mikroçekirdek mimarisiyle geliştirildi. Bunun ne demek olduğunu soruyorsan kısaca şunu bil :</p>
					<p>Dorkodia ek olarak bir güvenlik katmanına sahip. Yani sen onu kullanırken sürekli bu katmanla haşır neşir oluyorsun. Dorkodia\'da güvenlik hep ilk endişe kaynağımız oldu. Bu amaçla sürekli yeni kitaplar ve makaleler okuyup bu işi daha iyi yapmaya çalışıyoruz. Geliştirdiğimiz her yeni özelliği eklemeden günlerimizi onu daha güvenli yapmaya harcıyoruz.</p>
					<p>Yani bu konuda daha fazla endişelenmene gerek yok. Ancak tehlike sana bizden daha yakınsa, bize bu durumu bildir : <a href="mailto: trust@dorkodu.com">trust@dorkodu.com</a>.</p>
					';
					break;
				case 'yakinma':
					$formToken = $dorAuth->generateLoginToken();
					$currentSession->setWebSession('dorkodia_sorToken', $formToken);
					$tabTitle = 'Yakınma';
					$tabContent = '<h2>Yakınma</h2>
					<p>Dorkodia\'da beğenmediğin bir özellik mi var? Bir şeyler seni rahatsız mı ediyor? Veya uygunsuz bir durumla mı karşılaştın? Tam doğru yerdesin.</p>
					<p>Eğer bunlardan biri senle eşleşiyorsa <span style="font-family:Roboto;">ve aşağıdaki durumlardan biri sana uymuyorsa</span> bize gerekenleri doldurarak bir yakınma mektubu gönder.</p>
						<div class="header-set" style="width:80%; margin:10px auto;">
							<h3>Yakınma Mektubu</h3>
						</div>					
					<form method="post" action="sor.php" style="width:80%; margin:0 auto; padding:5px; border-radius:2px; background-color: rgb(249, 251, 251); border:1px solid #ddebee; text-align:center;">
						<input type="hidden" name="challange" value="'.$formToken.'">
						<div class="form-row" style="margin:10px; text-align:left !important;">
							<label for="abuse-case">Yakındığın Konu :</label>
							<input id="abuse-case" name="abuse-case" type="text" class="input-text"> 
						</div>
						<div class="form-row" style="margin:10px; text-align:left !important;">
							<label for="abuse-details">Ayrıntılı Bilgi :</label>
							<textarea id="abuse-details" name="abuse-details" class="input-richtext" style="min-width:90% !important; max-width:90% !important; min-height:80px;" maxlength="1024"></textarea>
						</div>
						<div class="form-row" style="margin:10px; text-align:left !important;"><button type="submit"  name="abuse-send" class="input-submit" style="float:right; margin:5px 8%;">Gönder</button></div>
					</form>
					<ul>
					<h3 style="margin-top:15px;">Sık Yaşanan Durumlar Ve Çözümleri</h3>
					<li><a href="javascript:toggleVisible(\'ans1\')">SORUN : İstemediğim iletiler alıyorum</a></li>
					<div id="ans1" class="faq-box">
						ÇÖZÜM : Bunun için birkaç çözümümüz var :
						<ol>
							<li>Sana ulaşmasını veya seni görmesini engellemek istediğin bir kişiyi <a href="./gizlilik.php">Gizliliğim</a> sayfasından onun kullanıcı adını girerek uzaklaştırabilirsin.</li>
						</ol> 
					</div>
					</ul>
					';
					break;
				case 'oneri':
					$formToken = $dorAuth->generateLoginToken();
					$currentSession->setWebSession('dorkodia_sorToken', $formToken);
					$tabTitle = 'Öneri';
					$tabContent = '
					<div class="header-set" style="width:80%; margin:10px auto;">
						<h3>Özellik Önerileri</h3>
					</div>
					<p style="width:77%; margin:5px auto; font-family:Roboto; font-weight:bold;">Dorkodia\'ya yeni bir özellik öner!</p>				
					<form method="post" action="sor.php" style="width:77%; margin:0 auto; padding:5px; border-radius:2px; background-color: rgb(249, 251, 251); border:1px solid #ddebee; text-align:center;">
						<input type="hidden" name="challange" value="'.$formToken.'">
						<div class="form-row" style="margin:5px; text-align:left !important;">
							<label for="suggest-details">Bir fikrim var... </label>
							<textarea id="suggest-details" name="suggest-details" class="input-richtext" style="min-width:90% !important; max-width:90% !important; min-height:80px;" maxlength="512"></textarea>
						</div>
						<div class="form-row" style="margin:10px; text-align:left !important;"><button type="submit" name="suggest-send" class="input-submit" style="float:right; margin:5px 8%;">Gönder</button></div>
					</form>
					';
					break;
				case 'is':
					$tabTitle = 'İş ve Basın';
					$tabContent = '
					<div class="header-set" style="width:85%; margin:10px auto;">
						<h3>E-posta ile İletişime Geçin</h3>
					</div>
					<ul style="width:83%; margin:5px auto;">
						<li><span style="font-family:Roboto; text-align:right; font-weight:bold; color:#333; width:180px !important; float:left; display:inline; margin-right:10px;">İş Geliştirme :</span><a style="width: calc(100% - 160px);"href="mailto: is@dorkodu.com">is@dorkodu.com</a></li>
						<li><span style="font-family:Roboto; text-align:right; font-weight:bold; color:#333; width:180px !important; float:left; display:inline; margin-right:10px;">Basın :</span><a style="width: calc(100% - 160px);"href="mailto: basin@dorkodu.com">basin@dorkodu.com</a></li>
						<li><span style="font-family:Roboto; text-align:right; font-weight:bold; color:#333; width:180px !important; float:left; display:inline; margin-right:10px;"> <a href="./kagitucak.php">Dorkodia Kağıt Uçaklar</a> :</span><a style="width: calc(100% - 160px);"href="mailto: kagitucak@dorkodu.com">kagitucak@dorkodu.com</a></li>
						<li><span style="font-family:Roboto; text-align:right; font-weight:bold; color:#333; width:180px !important; float:left; display:inline; margin-right:10px;">Reklam :</span><a style="width: calc(100% - 160px);"href="mailto: reklam@dorkodu.com">reklam@dorkodu.com</a></li>
					</ul>
					<p style="width:65%; margin:10px auto;">Reklamlarla ilgili yukarıdaki <a href="./yardim.php?tab=reklam" alt="Reklam">Reklam</a> sekmesine göz atın. </p>
					';
					break;
				case 'reklam':
					$tabTitle = 'İş Olanakları';
					$tabContent = '
					<div class="header-set" style="width:85%; margin:10px auto;">
						<h3>Tüm sorularınız için...</h3>
					</div>
					<ul style="width:83%; margin:5px auto;">
						<li><span style="font-family:Roboto; text-align:right; font-weight:bold; color:#333; width:180px !important; float:left; display:inline; margin-right:10px;">Dorkodia Kağıt Uçakları :</span><a style="width: calc(100% - 160px);" href="./kagitucak.php">Kağıt Uçaklar</a></li>
						<li><span style="font-family:Roboto; text-align:right; font-weight:bold; color:#333; width:180px !important; float:left; display:inline; margin-right:10px;">Diğer Reklam Yolları :</span><a style="width: calc(100% - 160px); text-align:left;" href="./reklam.php">Doğal Reklam</a></li>
					</ul>
					<div style="width:83%; margin:0 auto; text-align:center;">
						<button type="button" onclick="javascript:window.location.href=\'https://dorkodia.tedxvefa.com\'" style="margin:5px auto;"class="input-submit">Anasayfa</button>
					</div>
					';
					break;
				case 'hakkinda':
					$tabTitle = 'Hakkında';
					break;
				default:
					break;
			}
		}
	}
?>
<!DOCTYPE html>
<html lang="tr" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>
	 <?php 
		if(isset($tabTitle) && !empty($tabTitle))
			echo $tabTitle;
		else
			echo "Yardım";
	 ?> - Dorkodia</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="shortcut icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
	<style>
		.see {
			display:block !important;
		}

		.faq-box {
			display:none;
		}

		ul h3 {
			margin:10px 0;
		}
	</style>
	<script>
		function toggleVisible(id) {
			document.getElementById(id).classList.toggle("see");
		}
	</script>
  </head>
  <body>
    <div id="book">
      <?php require_once "./req/header.php"; ?>
      <div id="pod">
        <?php require_once "./req/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1><?php echo $tabTitle; ?></h1>
        </div>
        <div id="content" class="intro">
          <div class="column base-column">
            <div class="set intro">
            <?php
					$tabArray = array(
						array('tab'=>"hakkinda", 'text'=>"Hakkında"),
						array('tab'=>"destek", 'text'=>"Destek"),
						array('tab'=>"guvenlik", 'text'=>"Güvenlik"),
						array('tab'=>"yakinma", 'text'=>"Yakınma"),
						array('tab'=>"oneri", 'text'=>"Öneri"),
						array('tab'=>"is", 'text'=>"İş ve Basın"),
						array('tab'=>"reklam", 'text'=>"Reklam")
					);
					echo '<div class="tabs">
								<ul>';
					foreach($tabArray as $tabElement) {
						if(isset($_GET['tab']) && ($tabElement['tab'] == $_GET['tab'])) {
							echo '<li class="current"><a href="./yardim.php?tab='.$tabElement['tab'].'">'.$tabElement['text'].'</a></li>';
						} else {
							echo '<li><a href="./yardim.php?tab='.$tabElement['tab'].'">'.$tabElement['text'].'</a></li>';
						}
					}
					echo '</ul></div>';
					echo $tabContent; 
				?>
            </div>
          </div>
        </div>
      </div>
      <?php require_once "./req/footer.php" ?>
    </div>
  </body>
</html>
