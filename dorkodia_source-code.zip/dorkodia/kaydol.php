<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneler, bu dosyada tanımlı...

	$r_token = $currentSession->getWebSession('dorkodia_registerToken');
	$r_captcha = $currentSession->getWebSession('dorkodia_captcha');

	//logout scripti gibi oldu maşaallah aman nazar değmesin...
	$dorAuth->freshSession($currentSession);

	//mevcut oturumu sonlandırınca asıl işe bakıyoruz
	if(isset($_POST['sure-for-legals'])) {
		//form gönderildi.
		$registerToken = htmlspecialchars($_POST['challange']);
		$uName = htmlspecialchars($_POST['r-username']);
		$uRealname = htmlspecialchars($_POST['r-realname']);
		$uPass = htmlspecialchars($_POST['r-pass']);
		$uEmail = htmlspecialchars($_POST['r-email']);
		$captcha = htmlspecialchars($_POST['r-captcha']);
		$isTermsAgreed = htmlspecialchars($_POST['sure-for-legals']);

		if ($registerToken == $r_token) {
			if ($captcha == $r_captcha) {
				if ($isTermsAgreed == 'checked') {
					$registerResponse = $dorAuth->registerNewUser($uName, $uRealname, $uEmail, $uPass);
					if((is_array($registerResponse) && $registerResponse[0] == false) || $registerResponse == false)
						$dorAuth->redirectToPage($dorkodia->getCurrentDocument().'?result=error&why='.$registerResponse['message']);
					elseif($registerResponse == true) {
						$dorAuth->redirectToPage('gir.php?result=know&why=register-achieved');
					}
				} else {
					$dorAuth->redirectToPage($dorkodia->getCurrentDocument().'?result=error&why=checkbox');
				}
			} else {
				$dorAuth->redirectToPage($dorkodia->getCurrentDocument().'?result=error&why=captcha');
			}
		} else {
			$dorAuth->redirectToPage($dorkodia->getCurrentDocument().'?result=error&why=token');
		}
	}
?>
<!DOCTYPE html>
<html lang="tr" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Kaydol - Dorkodia</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
  </head>
  <body>
    <div id="book">
      <?php require_once REQ_DIR."/header.php"; ?>
      <div id="pod">
        <?php require_once REQ_DIR."/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1>Dorkodia'ya Kaydol</h1>
        </div>
        <div id="content" class="intro">
          <div class="column base-column">
            <div class="set intro">
            <?php require_once REQ_DIR."/error-handler.php"; ?>
              <h2>Kaydol</h2>
              <p>Dorkodia'ya katılmak için aşağıdaki alanları doldur. Kaydolduktan sonra Dorkodia hesabına giriş yaparak kullanmaya başlayabilirsin.</p>
              <form class="register-form" action="kaydol.php" method="POST">
                <input type="hidden" id="challange" name="challange" value="<?php $token = $dorAuth->generateLoginToken(); $currentSession->setWebSession('dorkodia_registerToken', $token); echo $token; ?>">
                <div class="form-row">
                  <label for="r-realname">Gerçek Adın :</label>
                  <input class="input-text" type="text" name="r-realname" id="r-realname" autocomplete="off">
                </div>
                <div class="form-row">
                  <label for="r-username">Kullanıcı Adın :</label>
                  <input class="input-text" type="text" name="r-username" id="r-username" autocomplete="off">
                </div>
                <div class="form-row">
                  <label for="r-pass">Parola :</label>
                  <input class="input-text" type="password" name="r-pass" id="r-pass" autocomplete="off">
                </div>
                <div class="form-row">
                  <label for="r-email">E-posta :</label>
                  <input class="input-text" type="email" name="r-email" id="r-email" autocomplete="off">
                </div>
                <div class="form-row">
                  <label for="r-captcha">Resimdeki Metin :</label>
                  <input class="input-text" type="text" name="r-captcha" id="r-captcha" autocomplete="off">
                </div>
                <div class="form-row">
									<br>
								  <img src="<?php echo 'microservice/session-authentication/dorkodia-turinggen.php';  ?>">
									<br>
								</div>
                <div class="form-row">
                  <input type="checkbox" id="sure-for-legals" name="sure-for-legals" value="checked">
                  <label for="sure-for-legals" class="check-label"><a href="burokrasi.php?tab=kosullar">Kullanım Koşulları</a>nı okudum, anladım ve kabul ediyorum.</label>
                </div>
                <div class="form-row button-container">
                  <a href="gir.php">Zaten bir hesabım var</a>
                  <p>|</p>
                  <button type="button" name="doregister" id="doregister" onclick="this.disabled=true; this.form.submit();" class="input-submit">Şimdi Kaydol!</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <?php require_once "./req/footer.php" ?>
    </div>
		<script src="<?php echo SCRIPT_DIR."/register.js"; ?>" charset="utf-8"></script>
  </body>
</html>
