<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneleri
	if(!$isLoggedIn) {
		$dorAuth->redirectForLogin($dorkodia->getCurrentDocument());
	}  else {
		$currentUserID = $currentUser->getID();
		$dorkodia->connectToDreamchaserService();
	}
?>
<!DOCTYPE html>
<html lang="tr" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Keşfet - Dorkodia</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="shortcut icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
  </head>
  <body>
    <div id="book">
      <?php require_once "./req/header.php"; ?>
      <div id="pod">
        <?php require_once "./req/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1>Burası senin, <?php echo explode(' ', $currentUser->getFullName())[0];?>.</h1>
        </div>
        <div id="content">
          <div class="column base-column">
						<?php require_once REQ_DIR."/error-handler.php"; ?>
            <div class="set" id="dreamwall">
              <h2>Keşfet</h2>
							<?php if(!empty($resultBox)) echo $resultBox;?>
							<div class='message-box info'>
              	<h2>Keşfet'e Hoş Geldin!</h2>
								<p>Burası keşfet. Burada Dorkodia'da olup bitenden, etkinliklerden ve kısacası her şeyle ilgili yeniliklerden haberdar olabilirsin.</p>
              </div>
							<p>Sosyal ağ özelliğiyle birlikte burada daha zengin içerikleri görmeye başlayacaksın. $imdilik biraz etrafta gezin.</p>
                <div class="header-set">
                  <h3>Dorkodia'daki Yenilikler</h3>
                  <a href="tur.php">dahası...</a>
                </div>
								<p>Dorkodia ve özellikleriyle ilgili bilgi edinmek için <a href="tur.php">tura katıl.</a></p>
            </div>
          </div>
          <div class="column nav-column">
						<?php require_once REQ_DIR.'/nanofeed.php'; ?>
          </div>
        </div>
      </div>
      <?php require_once "./req/footer.php" ?>
    </div>
  </body>
</html>
