<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneleri
?>
<!DOCTYPE html>
<html lang="tr" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Eşsiz Ufuklar - Dorkodia</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="shortcut icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
  </head>
  <body>
    <div id="book">
      <?php require_once "./req/header.php"; ?>
      <div id="pod">
        <?php require_once "./req/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1>Eşsiz Ufuklar</h1>
        </div>
        <div id="content">
          <div class="column base-column">
            <div class="set">
              <h2>Dorkodu ve Eşsiz Ufuklar</h2>
              <img src="./image/dorkodu-banner.png" class="medium-image">
              <p class="blog-context"><i class="icon d-quote"></i> <strong>Ben Doruk.</strong> Burası da Dorkodu'nun bir parçası. Dorkodu insanlığın evrensel bilgi ağacını yaratmak için kurduğum bir girişim. Henüz yalnızca Dorkodu, Cyudebeam, Dorkodia, Hourglass projeleri üstünde çalışıyorum. <strong>Amacım insanlığın bilgi mirasını korumak ve geliştirmek; onların buna ulaşmasını ve kullanmasını kolaylaştırmak ve Dünya üzerindeki herkese bu hakkı tanımak.</strong>
              <br><br><img src="./image/banners/IMG_3788.JPG" class="large-image"><br>Dorkodu'daki temel çıkış noktası şudur :<br> İnsanlık günümüzde yolundan fazla sapmaya başladı. Bilgiye verilen değer, sadece internetteki gizliliğimizi hiçe sayan dev veri toplayıcı şirketlerle sınırlı. İnternetin verdiği güçle her bilgiye ulaşabildiğimizi düşünürken, yaptığımız şeyin yalnızca var olduğunu gördüğümüz web sayfalarında yine başkalarının yazdığı metinleri okumak, görsellere bakmak, videolarını izlemek veya seslerini dinlemek olduğunun farkında değiliz.<br><br>
              Ancak Dorkodu olarak biz bilginin daha evrensel ve doğru bir deneyimle edinilebileceğine inanıyoruz. Bilgi, evrendeki en büyük güçtür. Ve bunun farkında olanlar, diğer güçleri elde ederek bu evrene hükmeder.<br><br><img src="./image/banners/uzun-donemli-dusunme.jpg" class="large-image"><br>Sadece saf ve doğru bilgiye ulaşabildiğimiz, bilgi üzerine kurulu, ve yine bilgiye değer verenlerin işin içinde olduğu evrensel nitelikte bir bilgi kaynağı olmalıydı. Dorkodu işte bunun için yaratılacak. 
              <br><br>Dorkodu, insanların bilgi arayabileceği bir arama motoru, bilginin bu amaçla düzenli ve insan/bilgisayar ikilisi tarafından anlaşılacak düzeyde depolandığı sanal ve evrensel bir bilgi ağacıdır. Her kaynaktan bilgiler derlenerek ilgili şekilde depolanır. Her bilginin diğer bilgilerle ilişkisi ve kendi önem ve doğruluk değeri vardır. Bilgiler bu önem/doğruluk değerine göre sıralanır, ilişkilendirilir.<br><br>
              Ve biri bir şeyi aradığında ona sadece bilgi ulaşır, fazlası değil. Her bilgi bir diğerine bağlı olduğundan bilgiye ulaşmak, o bilgiyi kavramak ve kullanmak da kolaylaşır ve bir düzene girer.<br><br>İşte Dorkodu bu olacak, sana vaadettiğimiz tek şey bunlardan ibaret.<br><br>Eğer bu eşsiz ufukları sen de bizimle birlikte görmek istersen, <a href="buldum.php">şuraya</a> bir göz at.</p>
            </div>
            <div class="set">
              <h2>İnsanlar</h2>
              <p><b>Doruk Dorkodu</b> - <b>Yaratıcı</b>, Yazılım Mimarı ve Tasarımcı.</p>
              <p>Bu devrimin bir parçası olmak ister misin? Şuraya bir <a href="./buldum.php">göz at :D</a></p>
            </div>
          </div>
          <div class="column nav-column">
            <div class="set synapse">
              <h3>Hakkında</h3>
              <p>Dorkodia <a href="./hakkinda.php">hakkında</a> bilgi edin</p>
            </div>
            <div class="set synapse">
              <h3>Dorkodu'ya Katıl</h3>
              <p>Dorkodu'daki arananlar listesi için <a href="./buldum.php">buraya</a> bir göz at.</p>
            </div>
            <div class="set synapse">
              <h3>Meraklısı İçin</h3>
              <p>Dorkodia içinde <a href="./yardim.php?tab=sss">sıkça sorulan sorular</a>.</p>
            </div>
            <div class="set synapse">
              <h3>Fibula</h3>
              <p>Dorkodu'daki son konuşulanlar için; bilim, sanat ve kültür hakkında; Fibula'ya göz at.</p>
            </div>
          </div>
        </div>
      </div>
      <?php require_once "./req/footer.php" ?>
    </div>
  </body>
</html>
