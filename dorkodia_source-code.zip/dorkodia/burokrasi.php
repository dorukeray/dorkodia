<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneleri
	if(isset($_GET['tab'])) {
		if(!empty($_GET['tab'])) {
			$tab = $_GET['tab'];
			switch($tab) {
				case 'kosullar':
					$bizTitle = "Kullanım Koşulları";
					$bizContent = 
					"<h2>Başlarken</h2>
					<p>Dorkodia'ya hoş geldin. Dorkodia seni hayallerine bağlayan bir araçtır. Burası insanların fikir ve hayallerini paylaşabilecekleri, üstünde çalışabilecekleri ve onları gerçekleştirebilecekleri bir platformdur. Bu belgede ('Kullanım Koşulları Sözleşmesi', veya kısaca 'sözleşme') Dorkodia platformu için kısaca <b>Dorkodia</b> veya <b>web sitesi</b> diye bahsedilecektir. Bu web sitesini kullanırken bu tüm koşulları kabul ettiğiniz varsayılacaktır. Eğer kabul etmiyorsanız, web sitesini kullanmayın veya web sitesine erişmeyin. Bu sözleşmeyi güncellediğimizde bunu sürekli olarak tekrar gözden geçirmek sizin sorumluluğunuzdadır.</p>
					<h2>Uygunluk</h2>
					<p>Bu siteye erişmek ve/veya kullanmak için en az 13 yaşında olmalısınız. Bunun aksi durumlarda Dorkodia'daki içeriğe, özelliklere ve hizmetlere erişemezsiniz, kullanamazsınız. Bu şartlara uyduğunuzda bu web sitesini kullanmakta özgürsünüz, bu bağlamda Dorkodia'yı kullanarak bu sözleşmeyi kabul etmiş ve bir yükümlüsü sayılırsınız. Dorkodia üyeliğinizi herhangi bir sebepten herhangi bir zamanda sonlandırabilir.</p>
					<h2>Dorkodia'daki İçeriğin Hakları</h2>
					<p>Web sitesindeki tüm içerik, bunlarla sınırlı olmamakla birlikte tasarım, metin, grafikler, diğer dosyalar ve onların düzenlenmiş bütünü olan (İçerik), Dorkodia'nın özel fikri mülküdür. Tüm hakları saklıdır. İçerik değiştirilemez, kopyalanamaz, dağıtılamaz, tekrar üretilemez, tekrar yayınlanamaz, indirilemez, gösterilemez, gönderilemez, iletilemez veya herhangi bir biçimde satılamaz. Kendi içeriğinizi indirip, çoğaltıp sadece kendi ticari olmayan amaçlarınız için kullanabilirsiniz. İçeriğin diğer tüm kullanımı kesinlikle yasaktır.</p>
					<p>Tüm markalar, logolar, amblemler, ikonlar ve hizmet markaları ya Dorkodia'nın markasıdır ya da tüm hakları saklıdır ve kopyalanamaz, taklit edilemez, herhangi bir amaçla kullanılamaz. Tüm bu koşulların aksi durumlarının gerçekleşmesi ancak Dorkodia'nın yazılı iznine bağlıdır.</p>
					<h2>Web Sitesindeki Kullanıcı İçeriği</h2>
					<p><a href='burokrasi.php?tab=gizlilik'>Gizlilik İlkeleri</a>'nde belirtildiği üzere içeriğin tüm hakları Dorkodia'ya aittir. Dorkodia bunları herhangi bir amaçla kullanabilir,  (örn: size daha iyi bir günce önerisi sunmak için notlarınızı analiz edebilir.) herhangi bir şekilde işlem uygulayabilir, depolayabilir. Dorkodia'yı kullanarak ve şu anki sözleşmeyi kabul ederek, Gizlilik İlkeleri'ni de kabul etmiş sayılırsınız.</p>
					<p>Web sitesine herhangi bir içerik gönderirken tüm bu şartları kabul etmiş sayılırsınız. Gönderdiğiniz içeriğin tüm sorumluluğu size aittir. Unutmayın, içeriğiniz herhangi bir yasadışı eyleme veya amaca hizmet etmemelidir. Tüm karşıt amaçlar (sözlü şiddet, istismar, değerlere aykırı davranış, kuralları ihlal vs.) sizin sorumluluğunuzdadır.</p>
					<p>İstediğiniz zaman web sitesindeki içeriğinizi kaldırabilirsiniz. Bu durumda tüm bu şartlar geçerliliğini yitirir.</p>
					<h2>Telif Hakları</h2>
					<p>Dorkodia herkesin fikri mülkiyet haklarına saygı duyar. Bu konuda size (fikri mülkiyet hakkı sahibi kişiye karşı) bir ihlal olduğunu düşünüyorsanız bizimle iletişime geçin : <a href='mailto: telif@dorkodu.com'>copyright@dorkodu.com</a></p>
					<h2>Sorumluluk Reddi</h2>
					<p>Dorkodia hiçbir şekilde web sitesindeki herhangi bir yanlış içerikten veya Dorkodia hizmetinin kendisinden kaynaklanan bir sorundan sorumlu değildir. Dorkodia hiçbir şekilde vaadettiği hizmetleri eksiksiz yerine getirme sorumluluğu altında değildir. Hizmet kullanımda veya kullanım dışı olsa dahi, Dorkodia hiçbir konuda garanti vermez ve Dorkodia ile ilgili olsun ya da olmasın, yaşanabilecek herhangi bir sorundan dolayı sorumlu tutulamaz.</p>
					";
				break;
				case 'gizlilik':
					$bizTitle = "Gizlilik İlkeleri";
					$bizContent = 
					"<h2>Başlarken</h2>
					<p>Dorkodia seni hayallerine bağlayan bir araçtır. Bu belgede ('Gizlilik İlkeleri', veya kısaca 'ilkeler') Dorkodia platformu için kısaca <b>Dorkodia</b> veya <b>web sitesi</b> diye bahsedilecektir. Bu web sitesini kullanırken bu tüm koşulları kabul ettiğiniz varsayılacaktır. Eğer kabul etmiyorsanız, web sitesini kullanmayın veya web sitesine erişmeyin. Bu sözleşmeyi güncellediğimizde bunu sürekli olarak tekrar gözden geçirmek sizin sorumluluğunuzdadır.</p>
					<h2>Topladığımız Bilgi</h2>
					<p>Web sitesini ziyaret ettiğinizde bize birtakım bilgiler sağlıyorsunuz, bunlar kişisel bilgileriniz (Gerçek adınız, E-posta adresiniz) veya siteyi kullanımınızdan kaynaklanan kullanıcı içeriğiniz (Dorkodia içinde sağladığınız tüm bilgiler, aktiviteniz, paylaştıklarınız vs.)</p>
					<p>Siteye kullanıcı olarak giriş yaptığınızda sizin 1- internet tarayıcınız ve 2- IP adresinizi saklıyoruz. Bu tüm kullanıcılardan toplanan bir bilgidir. Ayrıca tarayıcınızda herhangi bir çerez depolamıyoruz, ancak kendi sunucumuzda sizin çeşitli oturum bilgilerinizi tutuyoruz, çıkış yaptığınızda veya tarayıcınızı kapattığınızda bu bilgiler yok olur.</p>
					<p>Dorkodia ayrıca sizin için başka kaynaklardan da veri toplayabilir, örneğin bizimle (Dorkodia, dorkodia.dorkodu.com, dorkodia.tedxvefa.com, dorkodia.com) ilişkili veya ilişkili olmayan başka hizmetlerden. Bu bilgiler sizin siteyi kullanımınızdan bağımsız da olabilir.</p>
					<h2>Topladığımız Bilginin Kullanımı</h2>
					<p>Yukarıdaki maddelerde belirtildiği üzere bize çeşitli bilgiler sağlıyorsunuz. Bunların doğruluğu tamamen sizin sorumluluğunuzdadır. Bu koşullarda sizin bu bilgilerinizi size hizmet verirken kullanıyoruz. Dorkodia ve özelliklerinde kullanmak için verilerinizi ve etkinliğinizi analiz edebiliriz, size bildirimler gönderebiliriz, yine web sitesinin hizmetlerinde size öneride bulunurken bu bilgileri kullanabiliriz.</p>
					<p>Ancak Dorkodia'ya sağladığınız bu bilgiler asla başka bir Dorkodia kullanıcısına siz Hesabım bölümündeki seçeneklerinizden izin vermedikçe erişilebilir olmayacaktır. Şu an için (20.04.2020 tarihi ile) bu zaten mümkün değildir. Ayrıca içeriğiniz ve bilginiz asla üçüncü bir tarafla paylaşılmamaktadır. Dorkodia gerekirse bunu da yapabilir. İlerisi için ise tekrardan bu ilkeleri gözden geçirmek sizin sorumluluğunuzdadır. </p>
					<h2>Kullanıcı İçeriğinin Değiştirilmesi</h2>
					<p>Dorkodia kullanıcıları giriş yaparak tüm kişisel bilgilerini değiştirebilir veya kaldırabilir. Ayrıca kullanıcılar hesaplarını kapatabilir. Bu durumda ise kişisel bilgileriniz ile tüm içeriğiniz ve etkinliğinizin verileri yok edilir.</p>
					<h2>Toplanılan Bilginin Depolanması ve Güvenliği</h2>
					<p>Dorkodia gereken tüm önlemleri almaktadır. Bunun için özel bir güvenlik katmanı geliştirdik. Eğer doğrulanmamış bir istek varsa bu işlem gerçekleşmez. Bu güvenlik katmanını web sitesinin kendisinden dahi önce geliştirdik. Bu bile kullanıcı içeriğine gösterdiğimiz özeni gösterse de mükemmel olmayabilir. Dorkoda hiçbir şekilde verilerin ve içeriğin tam güvenliğini taahhüt etmez, verinin kaybı veya bozulması durumlarından Dorkodia sorumlu değildir.</p>
					";
				break;
				default:
					$dorAuth->redirectToPage('index.php');
				break;
			}
		} else {
			
		}
	}
?>
<!DOCTYPE html>
<html lang="tr" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title><?php echo $bizTitle; ?> - Dorkodia</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="shortcut icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
  </head>
  <body>
    <div id="book">
      <?php require_once "./req/header.php"; ?>
      <div id="pod">
        <?php require_once "./req/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1><?php echo $bizTitle; ?></h1>
        </div>
        <div id="content" class="intro">
          <div class="column base-column">
            <div class="set intro">
					<?php echo $bizContent; ?>
            </div>
          </div>
        </div>
      </div>
      <?php require_once "./req/footer.php" ?>
    </div>
  </body>
</html>

