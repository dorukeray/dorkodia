<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneleri
?>
<!DOCTYPE html>
<html lang="tr" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Reklam - Dorkodia</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="shortcut icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
  </head>
  <body>
    <div id="book">
      <?php require_once "./req/header.php"; ?>
      <div id="pod">
        <?php require_once "./req/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1>Dorkodia'da Reklam Ver</h1>
        </div>
        <div id="content" class="intro">
          <div class="column base-column">
            <div class="set intro">
					<div style="width:68%; float:left;">
						<h4 style="color:#333;">Dorkodia Ne?</h4>
						<p>Az çok yaşam amacı olan bir gence sor, &nbsp;Dorkodia onların günlük yaşamının dikkat çeken bir parçası. Her gün, genç kuşaktan yüz binlercesi sosyal medyayı kontrol ettiği sıklıkta Dorkodia'ya giriş yapıyor. Dorkodia genç kuşak için #1 çevrimiçi uğraş ortamı.</p>
						<h4 style="color:#333;">Neden Dorkodia'da Reklam Vereyim Ki?</h4>
						<p>
							<span style="font-family:Roboto; font-weight:bold;">Yerel : </span>Sadece hedefindeki kitleye reklam ver.
							<br><span style="font-family:Roboto; font-weight:bold;">Etkili : </span>Genç kuşağa nerede ve ne zaman en çok etkiliyse öyle ulaş.
							<br><span style="font-family:Roboto; font-weight:bold;">Değer : </span>Diğer tüm reklamlardan daha az öde ve daha çok yararlan.
						</p>
						<span style="font-family:Roboto; font-weight:bold; color:#333;">Dahası İçin :</span><br>
						<br>
						<ul>
							<li><span style="font-size:13px; text-align:right; color:#333; width:160px !important; float:left; display:inline; margin-right:10px;">[ Duyuru/El İlanı Reklamları ]</span><a style="width: calc(100% - 160px);" href="./kagitucak.php">Dorkodia Kağıt Uçaklar</a></li>
							<li><span style="font-size:13px; text-align:right; color:#333; width:160px !important; float:left; display:inline; margin-right:10px;">[ Diğer Reklam Yolları ]</span><a style="width: calc(100% - 160px); text-align:left;" href="./dogal-reklam.php">Doğal Reklam</a></li>
						</ul>
					</div>	
					<img src="./image/banners/sign_in_promo.png" class="small-image">
					<img src="./image/banners/karliligi-kazanci-artirmak.jpg" class="small-image">
            </div>
          </div>
        </div>
      </div>
      <?php require_once "./req/footer.php" ?>
    </div>
  </body>
</html>
