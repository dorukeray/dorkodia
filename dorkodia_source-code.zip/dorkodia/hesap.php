<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneleri
	if(!$isLoggedIn) {
		$dorAuth->redirectForLogin($dorkodia->getCurrentDocument());
	} else {
		$currentUserID = $currentUser->getID();
		$dorkodia->connectToDreamchaserService();
		$userRequester = new User();
		$resultBox = "";
		if(isset($_POST['dorkodiaID-submit'])) {
			$neuRealname = addslashes(htmlspecialchars($_POST['my-realname']));
			$neuUsername = addslashes(htmlspecialchars($_POST['my-username']));
			$neuEmail = addslashes(htmlspecialchars($_POST['my-email']));

			if (!empty($neuRealname) && !empty($neuUsername) && !empty($neuEmail)) {
				$neuUserInfo = new User();
				$neuUserInfo->setUser($currentUserID, $neuUsername, $neuRealname, $currentUser->getHashedPass(), $neuEmail);
				if($neuUsername != $currentUser->getUsername()) {
					if(!$dorUser->isUsernameTaken($neuUsername)) {
						if($dorUser->updateUserInfo('Username', $neuUsername, $currentUserID)) {
							$resultBox = "<div class='message-box info'>
												<h2>Bilgi</h2>
												<p>Bilgilerin başarıyla güncellendi.</p>
												</div>";
							$currentUser = $dorUser->getUserById($currentUserID);
							$dorUser->saveUserToWebSession($currentUser);
						} else {
							$resultBox = "<div class='message-box error'>
												<h2>Hata</h2>
												<p>Bir hata oluştu. Bilgilerin güncellenemedi.</p>
												</div>";
						}
					} else {
						$resultBox = "<div class='message-box error'>
													<h2>Bu Kullanıcı Adı Zaten Var</h2>
													<p>Bu kullanıcı adı daha önce alınmış. Başka bir ad bulmayı deneyin.</p>
												 	</div>";
					}
				} if ($neuRealname != $currentUser->getFullName()) {
					if($dorUser->updateUserInfo('Fullname', $neuRealname, $currentUserID)) {
						$resultBox = "<div class='message-box info'>
											<h2>Bilgi</h2>
											<p>Bilgilerin başarıyla güncellendi.</p>
											</div>";
						$currentUser = $dorUser->getUserById($currentUserID);
						$dorUser->saveUserToWebSession($currentUser);
					} else {
						$resultBox = "<div class='message-box error'>
											<h2>Hata</h2>
											<p>Bir hata oluştu. Bilgilerin güncellenemedi.</p>
											</div>";
					}

				} if($neuEmail != $currentUser->getEmail()) {
					if($dorUser->updateUserInfo('Email', $neuEmail, $currentUserID)) {
						$resultBox = "<div class='message-box info'>
											<h2>Bilgi</h2>
											<p>Bilgilerin başarıyla güncellendi.</p>
											</div>";
						$currentUser = $dorUser->getUserById($currentUserID);
						$dorUser->saveUserToWebSession($currentUser);
					} else {
						$resultBox = "<div class='message-box error'>
											<h2>Hata</h2>
											<p>Bir hata oluştu. Bilgilerin güncellenemedi.</p>
											</div>";
					}
				}
			} else {
			$resultBox = "<div class='message-box warning'>
											<h2>Uyarı</h2>
											<p>Bak, eğer bilgilerini girmezsen olmayan bir şeyi değiştiremeyiz.</p>
										</div>";
			}
		} elseif(isset($_POST['neopass-submit'])) { //parola deği$ikliği
			$oldPass = htmlspecialchars($_POST['my-current-pass']);
			$neuPass = htmlspecialchars($_POST['my-neo-pass']);
			if (!empty($oldPass) && !empty($neuPass)) {
				if (password_verify($oldPass, $currentUser->getHashedPass())) {
					$neuHash = password_hash($neuPass, PASSWORD_DEFAULT);
					if($dorUser->updateUserInfo('Password', $neuHash, $currentUserID)) {
						$resultBox = "<div class='message-box info'>
											<h2>Bilgi</h2>
											<p>Parolan başarıyla değiştirildi.</p>
											</div>";
						$currentUser = $dorUser->getUserById($currentUserID);
						$dorUser->saveUserToWebSession($currentUser);
					} else {
						$resultBox = "<div class='message-box error'>
											<h2>Hata</h2>
											<p>Bir hata oluştu. Parolan değiştirilemedi.</p>
											</div>";
					}
				} else {
					$resultBox = "<div class='message-box error'>
													<h2>Hata</h2>
													<p>Girdiğiniz parola yanlış. Lütfen doğru olduğundan emin olun.</p>
												</div>";
				}
			} else {
				$resultBox = "<div class='message-box warning'>
												<h2>Uyarı</h2>
												<p>Bak, eğer bilgilerini girmezsen olmayan bir şeyi değiştiremeyiz.</p>
											</div>";
			}

		}
	}
?>
<!DOCTYPE html>
<html lang="tr" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Hesabım - Dorkodia</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="shortcut icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
  </head>
  <body>
    <div id="book">
      <?php require_once "./req/header.php"; ?>
      <div id="pod">
        <?php require_once "./req/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1>Hesabım</h1>
        </div>
        <div id="content">
          <div class="column base-column">
						<?php require_once REQ_DIR."/error-handler.php"; ?>
            <div class="set">
              <div class="my-account-set">
                <h2>Kimliğim</h2>
                <p>Burada kullanıcı bilgilerini değiştirebilirsin.</p>
								<?php if(!empty($resultBox)) echo $resultBox;?>
								<br>
                <form action="hesap.php" method="post">
                  <div class="form-row">
                    <label for="my-realname">Gerçek Adım :</label>
                    <input class="input-text" type="text" name="my-realname" id="my-realname" value="<?php echo $currentUser->getFullName(); ?>" autocomplete="off">
                  </div>
                  <div class="form-row">
                    <label for="my-username">Kullanıcı Adım :</label>
                    <input class="input-text" type="text" name="my-username" id="my-username" value="<?php echo $currentUser->getUsername(); ?>" autocomplete="off">
                  </div>
									<div class="form-row">
										<label for="my-email">E-postam :</label>
										<input type="email" id="my-email" name="my-email" class="input-text" value="<?php echo $currentUser->getEmail(); ?>">
									</div>
	                <div class="form-row button-container">
	                  <button type="submit" name="dorkodiaID-submit" class="input-submit">Kaydet</button>
	                </div>
								</form>
                <h4>Parola Değişikliği</h4>
								<form class="" action="hesap.php" method="post">
									<div class="form-row">
                    <label for="my-current-pass">Şu anki Parolam :</label>
                    <input type="text" id="my-current-pass" name="my-current-pass" class="input-text">
                  </div>
                  <div class="form-row">
                    <label for="my-neo-pass">Yeni Parolam :</label>
                    <input type="password" id="my-neo-pass" name="my-neo-pass" class="input-text">
                  </div>
                  <div class="form-row button-container">
                    <button type="submit" name="neopass-submit" id="neopass-submit" class="input-submit">Parolamı Değiştir</button>
                  </div>
                  <br>
                </form>
              </div>
              <div class="my-account-set">
                <h2>Seçenekler</h2>
								<p>Henüz bir sosyal ağa dönüşmedik. Bu yüzden bir süre tek başına takılacaksın. Bu sürede değiştirebileceğin bir özellik yok.<br><b>$u anda bir hayal takip uygulamasındasın.</b></p>
								<br>
								<form action="elveda.php" method="post">
									<div class="form-row">
										<label for="delete-my-account" style="width:60%; float:left; margin:0 10px; text-align:left;">Dorkodia'dan Ayrılmak İstiyorum.</label>
										<button type="submit" name="delete-my-account" id="delete-my-account" class="input-submit">Hesabımı Sil</button>
									</div>
								</form>
								<br>
							</div>
            </div>
          </div>
          <div class="column nav-column">
            <?php require_once REQ_DIR.'/nanofeed.php'; ?>
          </div>
        </div>
      </div>
      <?php require_once "./req/footer.php" ?>
    </div>
  </body>
</html>
