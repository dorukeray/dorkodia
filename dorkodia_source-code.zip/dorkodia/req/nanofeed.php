<?php
  //Dorkodia Nanofeed Generator

  $context = ""; //içerik.

  function newSynapse($title, $content) {
	  echo "<div class='set synapse'>
			  <h3>".$title."</h3>
			  <p>".$content."</p>
			</div>";
  }

  function convertDate($dateString)
  {
    $newString = "";
    if(date('Y-m-d') == substr($dateString, 0, 10)) {
      $newString .=  substr($dateString, 11, 5);
      return $newString;
    } else {
      return $dateString;
    }
  }

 //nanofeed sınıfı oluştur.

  if(!$isLoggedIn) {
	 switch($dorkodia->getCurrentDocument()) {
		default:
			newSynapse("", "Burada hiçbir şey yok.");
			break;
	}
	echo $context;
  } else {
	  newSynapse("Bildirimler", "Burada hiçbir şey yok.");
    $statusRequest = new Thought();
    if($statusRequest->getStatus($currentUser->getID())) {
      $statusBody = "<p><i class='icon d-quote'></i> {$statusRequest->getContent()}<span style='color:var(--dorkodia-label); font-weight:normal;'> &bull; ".convertDate($statusRequest->getTimestamp())."</span></p>";
      newSynapse("Durum <a href='durum.php' style='display:inline; margin:1px 0; float:right; font-size:11px; font-family:Ubuntu; font-weight:normal;'>güncelle</a>", $statusBody);
    } else {
      newSynapse("Durum <a href='durum.php' style='display:inline; margin:1px 0; float:right; font-size:11px; font-family:Ubuntu; font-weight:normal;'>güncelle</a>", "Son durumun yok.");
    }
	  newSynapse("Nanofeed Bu Muydu?","Burada göremediklerin, çok yakında etkin olacak. <br>O zaman yeni bir düşünce akışın daha olacak.<br>Buna da <b>bilinçaltı</b> diyeceğiz.");
	}
?>
