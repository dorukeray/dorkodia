<?php
// Dorkodia Footer
echo "
<!-- javascript -->
<script src='./script/dorkodia_core.js' type='text/javascript' async></script>
<div id='page-footer'>
  <ul id='fnav'>
    <li><a href='hakkinda.php'>hakkında</a></li>
    <li><a href='essiz-ufuklar.php'>eşsiz ufuklar</a></li>
    <li><a href='buldum.php'>buldum!</a></li>
    <li><a href='yardim.php?tab=destek'>sss</a></li>
    <li><a href='burokrasi.php?tab=kosullar'>kullanım koşulları</a></li>
    <li><a href='burokrasi.php?tab=gizlilik'>gizlilik</a></li>
  </ul>
  <p>bir Doruk Dorkodu ürünüdür.</p>
  <p><strong>Dorkodia © 2020</strong></p>
</div>";
ob_end_flush();
