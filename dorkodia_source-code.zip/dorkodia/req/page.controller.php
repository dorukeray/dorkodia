<?php
	$dorkodia = new Dorkodia();
	$dorkodia->connectToAuthenticationService();
	$dorkodia->connectToUserService();
	$dorAuth = new DorkodiaAuthentication();
	$dorUser = new DorkodiaUser();
	$currentSession = new Session();

	//keşke burada global kullanıp PHP'nin bug'ını çıkarsam :p
	$isLoggedIn;

	//if you wanna understand the line twice-below, please listen to :
	// something is always wrong -- toad the wet sprocket, track #7
	$currentUserID = $dorAuth->isSomeoneLoggedIn();
	if(!$currentUserID) {
		$isLoggedIn = false;
		//girş yapmak için ortamı hazırla
		$currentSession;
	} else {
		//mevcut user idsi $currentUserID'de.
		//yeni oturum
		$isLoggedIn = true;

		//eğer oturum var ama kullanıcı verisi yoksa sessionla.
		if(!$currentSession->getSessionByWeb()) {
			//vtden çek
			$currentSession->getSessionByUserId($currentUserID);
			$currentSession->saveSessionToWeb();
		} else {
			$currentSession->getSessionByWeb();
		}

		//kullanıcıyı getir
		$currentUser = new User();
		if(!$dorAuth->getCurrentUser()) {
			$currentUser = $dorUser->getUserById($currentUserID);
			$dorUser->saveUserToWebSession();
		} else {
			$currentUser = $dorAuth->getCurrentUser();
		}
	}
