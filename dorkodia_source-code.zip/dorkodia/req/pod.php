<?php
  //Dorkodia Pod Generator
  $thisPage = $dorkodia->getCurrentDocument(); //mevcut sayfa
  $isLoggedIn = $dorAuth->isSomeoneLoggedIn(); //giriş yapıldı mı?
  $context = ""; //içerik
  $loginToken = $dorAuth->generateLoginToken();
  $rapidLogin = "<div id='rapidlogin'>
        				  <form class='rapidlogin' action='gir.php' method='post'>
          				  <input id='challange' type='hidden' name='challange' value='$loginToken'>
          					<label for='username'>Kullanıcı Adı :</label>
          					<input class='input-text' type='text' name='username' id='username' autocomplete='off'>
          					<label for='pass'>Parola :</label>
          					<input class='input-text' type='password' name='pass' id='pass'>
          					<div class='rapidlogin-button-container'>
          					  <button type='button' name='dorapidlogin' id='dorapidlogin' onclick='this.disabled=true; this.form.submit();' class='input-submit'>Giriş yap</button>
          					</div>
        				  </form>
        				</div>";

  $welcomeButtons = "<div class='welcome-buttons-under-rapidlogin'>
				  <a href='kaydol.php' class='tour-button'>
					<h4><i class='icon d-caret-right'></i>Kaydol</h4>
					<p>Dorkodia'ya katıl.</p>
				  </a>
				  <a href='tur.php' class='tour-button'>
					<h4><i class='icon d-caret-right'></i>Tura Katıl</h4>
					<p>Dorkodia hakkında öğren.</p>
				  </a>
				</div>";

 $onlyTour = "<div class='welcome-buttons-under-rapidlogin'>
				  <a href='tur.php' class='tour-button'>
					<h4><i class='icon d-caret-right'></i>Tura Katıl</h4>
					<p>Dorkodia hakkında öğren.</p>
				  </a>
				</div>";
 $onlyRegister = "<div class='welcome-buttons-under-rapidlogin'>
				  <a href='kaydol.php' class='tour-button'>
					<h4><i class='icon d-caret-right'></i>Kaydol</h4>
					<p>Dorkodia'ya katıl.</p>
				  </a>
				</div>";

  if(!$isLoggedIn) {
	 switch($thisPage) {
		case "gir.php":
			$context = $welcomeButtons;
		break;
		case "kaydol.php":
			$context = $onlyTour;
		break;
		case "404.php":
			$context = $onlyTour;
		break;
		case "tur.php":
      $currentSession->setWebSession('dorkodia_loginToken', $loginToken);
			$context = $rapidLogin.$onlyRegister;
		break;
		case "index.php":
      $currentSession->setWebSession('dorkodia_loginToken', $loginToken);
			$context = $rapidLogin;
		break;
		default:
      $currentSession->setWebSession('dorkodia_loginToken', $loginToken);
			$context = $rapidLogin.$welcomeButtons;
		break;
	}
	echo $context;
  } else {
	  $podLinks = array(
    array('title' => "Hayallerim", 'url' => "hayal.php", 'icon' => "cloud-2"),
    array('title' => "Durumum", 'url' => "durum.php", 'icon' => "quote"),
    array('title' => "Notlarım", 'url' => "not.php", 'icon' => "script"),
    array('title' => "Güncem", 'url' => "gunce.php", 'icon' => "news"),
    array('title' => "Hesabım", 'url' => "hesap.php", 'icon' => "user-1")
  );
	  echo "<div id='search-box'>
			  <form action='ara.php' method='get'>
				<div class='icon d-search'></div>
				<input type='text' name='q' placeholder='Ara' autocomplete='off'>
				<button type='submit' id='search-btn' hidden></button>
			  </form>
			</div>
			<ul id='pnav'>";

		foreach($podLinks as $podLink) {
			if($thisPage == $podLink['url'])
				$classified = "class='current'";
			else
				$classified = "";
			echo "<li><a href='{$podLink['url']}' {$classified}><i class='icon d-{$podLink['icon']}'></i>{$podLink['title']}</a></li>";
		}
		echo"</ul>";
	}
?>
