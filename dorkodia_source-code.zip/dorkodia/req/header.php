<?php
  //Dorkodia header links
  $userLinks = array(
    array('title' => "anasayfa", 'url' => "./anasayfa.php"),
    array('title' => "ara", 'url' => "./ara.php"),
    array('title' => "keşfet", 'url' => "./kesfet.php"),
    array('title' => "yardım", 'url' => "./yardim.php"),
    array('title' => "çıkış", 'url' => "./uzaklas.php")
  );
  $guestLinks = array(
    array('title' => "hakkında", 'url' => "./hakkinda.php"),
    array('title' => "giriş yap", 'url' => "./gir.php"),
    array('title' => "kaydol", 'url' => "./kaydol.php"),
    array('title' => "yardım", 'url' => "./yardim.php")
  );

  echo "<div id='page-header'>
    <div id='pheader-insights'>
      <div id='homelink'>
		  <a href='./index.php'>
			<h1>dorkodia</h1>
		  </a>
      </div>
      <div id='hnav'>
        <ul>";
      if ($isLoggedIn) {
				foreach($userLinks as $link) {
					echo "<li><a href='".$link['url']."'>".$link['title']."</a></li>";
				}
			} else {
				foreach($guestLinks as $link) {
					echo "<li><a href='".$link['url']."'>".$link['title']."</a></li>";
				}
			}
		    echo "
        </ul>
      </div>
    </div>
  </div>";
