<?php
		$title = "";
		$content = "";
		$why = "";
		$type = "";
		if(isset($_GET['result']) && !empty($_GET['result'])) {
			switch($_GET['result']) {
				case 'error':
					$type="error";
					$title="Hata";
				break;
				case 'know':
					$type="info";
					$title="Bilgi";
				break;
				case 'notice':
					$type="warning";
					$title="Uyarı";
				case '':
					break;
			}
			if(isset($_GET['why']) && !empty($_GET['why']))
				$why = $_GET['why'];

			switch($type) {
				case "error":
					switch($why) {
						case "token":
							$title .= " - Geçersiz jeton";
							$content = "Bir hata oluştu. Ya bir saldırıdan kuşkulanıyoruz ya da sizden kaynaklı değilse her ne yaptıysanız tekrar deneyin.";
							break;
						case "invalid-char":
							$title .= " - Geçersiz karakter";
							$content = "Lütfen kullanıcı adınızda ve gerçek isminizde sadece harf, rakam ve _ (alt tire) kullanın. Kullanıcı adınızda türkçe karakter kullanmayın.";
							break;
						case "username-taken":
							$title .= " - Bu Kullanıcı Adı Zaten Alınmış";
							$content = "Başka bir kullanıcı adı bulmayı deneyin.";
							break;
						case "empty-values":
							$title .= " - Boş Alanlar";
							$content = "Lütfen tüm bilgileri eksiksiz doldurun.";
							break;
						case "login":
							$title .= " - Giriş";
							$content = "Kullanıcı adı veya parolanızı doğru girdiğinizden emin olun.";
							break;
						case "captcha":
							$title .= " - Captcha Kodu Hatalı";
							$content = "Lütfen resimdeki güvenlik kodunu dğru girdiğinizden emin olun.";
							break;
						case "session":
							$title .= " - Oturum Güvenliği";
							$content = "Oturumda bir hata oluştu. Ya bir saldırıdan kuşkulanıyoruz ya da sizden kaynaklı değilse yeniden giriş yapmayı deneyin.";
							break;
						case "invalid-email":
							$title .= " - Geçersiz E-posta Adresi";
							$content = "Girdiğiniz e-posta adresi geçerli değil. Hatta gerçek bile olmayabilir. Ufak atın da civcivler yesin :/";
							break;
						default:
							$content = "Bir hata oluştu. Lütfen ne yaptıysanız tekrar deneyin, yine bu hatayı alıyorsanız endişelenmeyin. Su akar, yolunu bulur.";
							break;
					}
				break;
				case "info":
					switch($why) {
						case "update":
							$title .= " - Dorkodia";
							$content = "Dorkodia devrim geçiriyor. Bu biraz sürebilir, ya da birden karşılaşabilirsin.";
							break;
						case 'register-achieved':
						$title = "Dorkodia'ya hoş geldin!";
							$content = "Hesabın başarıyla oluşturuldu. Şimdi giriş yap ve kullanmaya başla";
							break;
						default:
							$title = "Bi Bilgi";
							$content = "Umarım ki eğlenmiyorsun. Unutma, mutlu insanın hikayesi olmaz. (Charles Dickens)";
							break;
					}
				break;
				case "warning":
					switch($why) {
						case "browser":
							$title = "Sorun... Internet Tarayıcın";
							$content = "Dorkodia bir devrim yaratıyor. Ve buna uyum sağlayabilmen için tarayıcının düzgün çalışıyor olmasına ihtiyaç var. Eğer olanağın varsa güncelle, yoksa düzgün çalıştığına emin ol.";
							break;
						default:
							$content = "Bi şeyler yanlış gitmiş olabilir, seni uyarıyoruz.";
							break;
					}
				break;
			}
		$box = "<div class='message-box ".$type."'>
					<h2>".$title."</h2>
					<p>".$content."</p>
				  </div>";
		echo $box;
	}
	if($dorkodia->getCurrentDocument() == 'gir.php' && isset($_GET['to']) && !empty($_GET['to'])) {
		echo "<div class='message-box warning'>
					<h2>Giriş yap</h2>
					<p>Bu sayfayı görebilmek için lütfen önce giriş yap.</p>
				  </div>";
	}
?>
