<?php
	//oturum varsa çıkış yap, yoksa index'e yönlendir.
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneler
	
	if(!$isLoggedIn) {
		$dorAuth->redirectToPage('./');
	} elseif($isLoggedIn) {
		//logout kodu
		$dorAuth->freshSession($currentSession);
		$dorAuth->redirectToPage('./');
	}
?>
