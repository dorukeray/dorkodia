<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneleri
?>
<!DOCTYPE html>
<html lang="tr" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Buldum! - Dorkodia</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="shortcut icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
    <style>
		.set.intro h2 {
			border-bottom:1px solid #cdd;
		}
		.set.intro h4 {
			color:#444;
			margin: 10px 0 !important;
		}
		.set.intro p {
			margin: 10px 0 !important;
		}
		ul.disc-bullets li span{
			color: #444;
			font-size:13px;
		}
    </style>
  </head>
  <body>
    <div id="book">
            <?php require_once "./req/header.php"; ?>
      <div id="pod">
        <?php require_once "./req/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1>Dorkodu'da Çalışma Fırsatları</h1>
        </div>
        <div id="content" class="intro">
          <div class="column base-column">
            <div class="set intro">
              <h2>nE ?!</h2>
              <img src="./image/dorkodu-banner.png" class="medium-image">
              <p>Dorkodu şu an için üssü olmayan bir girişim. Burada amaç insanlığın bilgi mirasına katkı sağlamak, insanlığı ileri taşımak ve insanlığın kendi bilgi birikimine ulaşmasını, onu kullanmasını kolaylaştıracak bir sanal evren yaratmaktı.</p>
              <img src="./image/banners/2.jpg" class="small-image">
              <img src="./image/banners/1.jpg" class="small-image">
              <img src="./image/banners/dollar.jpg" class="small-image">
              <p><b>Dorkodu Arama Motoru</b> ve <b>Cyudebeam Bilgi Ağı</b>yla bunu başlattım. Küçük bir günlük okul sonrası projesiydi,  ancak şu anda dünya genelinde yüz milyonlarca insanın bu ağa bağlanmasına yardımcı olacak şeylere gerek var. Ve bunun için artık tek başına bir lise öğrencisinin bunu yürütmesi imkansız.</p>
              <p>Şimdilik tamamen gönüllü olarak bu projelerde,  özgür yazılım mantığıyla çalışabilecek birkaç 15-25 yaş arası kişi yeterli olur. Ancak kim bilir, bir sonraki trilyon dolarlık şirket şu an doğuyor olmasın?</p>
              <p>Dorkodu'da strateji basit. Bulabildiğimiz en akıllı ve tutkulu insanları alıyoruz. Bu yüzden ilgini çektiyse şunlara bir göz at.</p>
            </div>
            <div class="set intro">
					<h2>Yazılım Mühendisliği</h2>
					<p>Dorkodu için perdenin arkasında şov için özverili bir şekilde gerekenleri hazırlayacak, Dorkodu'nun eşsiz ve 10 yıl ileride teknolojisinin kalbini geliştirecek tutkulu dahiler arıyoruz.</p>
					<p>Konum sadece İstanbul, TR.</p>
					<h4>Mühendislik</h4>
					<ul class="disc-bullets">
						<li><span>Bilgisayar Bilimleri veya eşdeğer alanlarda lisans, yüksek lisans veya doktora. Hiç olmazsa +5 yıllık ileri düzeyde deneyim ve yüksek ilgi/tutku bir kağıt parçasına (diploma, diyebiliriz) eş değer olabilir.</li>
						<li><span>*NIX ortamları, C/C++, dağıtık sistemler, makine öğrenmesi, bilgi getirimi, TCP/IP ve ağ programlama ve/veya geniş ölçekli yazılım sistemleri geliştirme konularında tecrübe, bir artı olarak.</span></li>
						<li><span>PHP, Python veya başka bir betik dili bilgisi, bir artı olarak.</span></li>
					</ul>
					<h4>Yazılım Mimarlığı</h4>
					<ul class="disc-bullets">
						<li><span>Yazılım Mühendisliği alanında sektörde +5 yıl deneyim, eşdeğer eğitim ve yüksek ilgi/tutku.</span></li>
						<li><span>Mimariler hakkında derin bilgi, AGILE / SCRUM / XP yazılım süreçlerinde deneyim</span></li>
						<li><span>İleri düzey programlama bilgisi, yüksek insan ilişkileri, yaratıcılık, felsefe ve psikoloji (b)ilgisi, temel liderlik kapasitesi, bir artı olarak.</span></li>
					</ul>
					<p>Bu alanla ilgili daha fazla bilgi ve başvuru için iletişime geçin <a href="mailto:ik@dorkodu.com">ik@dorkodu.com</a></p>
            </div>
            <div class="set intro">
					<h2>Operasyonlar</h2>
					<p>Konum sadece İstanbul, TR.</p>
					<h4>Linux Sistem Yöneticisi</h4>
					<ul class="disc-bullets">
						<li><span>Güncel ve derin Linux ve Unix sistem yöneticiliği bilgisi</span></li>
						<li><span>Güncel deneyim olarak milyonlarca kullanıcılı yüksek-ölçek geliştirme süreçli web sitelerinin kurulumu, yükseltilmesi ve sürdürülmesi.</span></li>
						<li><span>Güncel Apache, PHP, Perl ve Python betiklemesi, MySQL, MongoDb/NoSQL ve x86/x64 donanım deneyimi.</span></li>
					</ul>
					<p>Bu alanla ilgili daha fazla bilgi ve başvuru için iletişime geçin <a href="mailto:ik@dorkodu.com">ik@dorkodu.com</a></p>
				</div>
            <div class="set intro">
					<h2>Finans</h2>
					<p>Uzaktan çalışma olanağı var.</p>
					<h4>Reklam</h4>
					<p>Finans ve Reklam sorumluları Dorkodu çevrimiçi reklamlarını ilgili alanlardaki otoritelere satmaktan ve Dorkodu'nun pazarlama ve reklam sektöründe bilinirliliğini arttırmaktan sorumlu olacak.</p>
					<ul class="disc-bullets">
						<li><span>Finansal girdi için Dorkodu'nun felsefesini, ürününü; iş modelini ve internetten etik olarak para basma yöntemlerini derinlemesine kavramak,</span></li>
						<li><span>Kullanıcı ve Finansal Ortakların hedeflerini ve felsefesini anlayabilen/analiz edebilen ve bunları Dorkodu'nun sunduğu fırsatlarla etkili şekilde çakıştırabilmek,</span></li>
						<li><span>Ekonomi, Finans, Psikoloji, Sosyoloji, Bilgisayar Bilimi, Yazılım, Internet veya Reklam alanlarından en az ikisinde derin (b)ilgi sahibi olmak</span></li>
					</ul>
					<p>Bu alanla ilgili daha fazla bilgi ve başvuru için iletişime geçin <a href="mailto:ik@dorkodu.com">ik@dorkodu.com</a></p>
				</div>
            <div class="set intro">
					<h2>Ürün Yönetimi / Ürün Tasarımı / Ürün Geliştirme</h2>
					<p>Konum sadece İstanbul, TR.</p>
					<h4>Proje Lideri</h4>
					<ul class="disc-bullets">
						<li><span>Başarılı web tabanlı tüketici ürünleri, tercihen çevrimiçi topluluk alanında belirgin deneyim (3-5 yıl)</span></li>
						<li><span>Temel olarak web teknolojilerinden anlamak, bir artı olarak</span></li>
						<li><span>Temel programlama becerileri, bir artı olarak</span></li>
					</ul>
					<h4>Ürün Yöneticisi</h4>
					<ul class="disc-bullets">
						<li><span>Yüksek iç motivasyonlu, aynı anda birçok işle uğraşabilecek ve web tabanlı topluluk ürünleriyle yatıp kalkacak akıllı ve hızlı karar verebilen insanlar</span></li>
						<li><span>Gerçek dünya deneyimi gerekmezken, kendinizin başlattığı veya yönettiği bir web ürünü yoksa lütfen başvurmayın</span></li>
					</ul>
					<p>Bu alanla ilgili daha fazla bilgi ve başvuru için iletişime geçin <a href="mailto:ik@dorkodu.com">ik@dorkodu.com</a></p>
				</div>
            <div class="set intro">
					<h2>Web Yazılım Geliştirme</h2>
					<p>Konum sadece İstanbul, TR.</p>
					<h4>Web Geliştirici</h4>
					<ul class="disc-bullets">
						<li><span>Kısaltmalarda akıcı mısın? AJAX, PHP, JS, HTML, CSS, REST, ATOM. Onları gözlerin kapalı birlikte çalışır hale getirebilir misin?</span></li>
						<li><span>Geliştiriciler geniş bir teknolojiler seti arasında küçük takımlar halinde imkansıza yakın kısa takvimlerle çalışmak zorunda.</span></li>
						<li><span>En az +2 yıl deneyimle bir çalışma geçmişi veya kendinin başlattığı manyak iyi projeler portfolyosu.</span></li>
					</ul>
					<h4>Tasarımcı</h4>
					<ul class="disc-bullets">
						<li><span>Biz küçük bir takımız (aslında şu an tekim), ve büyük grafik tasarım gereksinimlerimiz var</span></li>
						<li><span>Çeşitli tasarım araçlarıyla ilgili olmak, ekran ve baskı, GIMP/Photoshop'tan Inkscape/Illustrator'a kadar.</span></li>
						<li><span>İşi hızlandırmak ve kolaylaştırmak için biraz betik kodu yazmaktan korkmamak</span></li>
						<li><span>İyi çalışma deneyimi veya öldürücü bir tasarım portfolyosuna sahip olmak</span></li>
					</ul>
					<p>Bu alanla ilgili daha fazla bilgi ve başvuru için iletişime geçin <a href="mailto:ik@dorkodu.com">ik@dorkodu.com</a></p>
				</div>
          </div>
        </div>
      </div>
      <?php require_once "./req/footer.php" ?>
    </div>
  </body>
</html>
