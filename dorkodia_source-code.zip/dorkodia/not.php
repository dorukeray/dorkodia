<?php
	require_once "./microservice/dorkodia-kernel/dorkodia.kernel.php";
	//gerekli mikroservisler ve dahil edilen nesneler, bu dosyada tanımlı...
	if(!$isLoggedIn) {
		$dorAuth->redirectForLogin($dorkodia->getCurrentDocument());
	} else {
		$currentUserID = $currentUser->getID();
		$dorkodia->connectToDreamchaserService();
		$activityReporter = new Activity();
		//not listeleme
		$noteRequester = new Note();

		$resultBox = "";
		if(isset($_POST['take-note'])) { //not ekleme
			$noteTopic = addslashes(htmlspecialchars($_POST['note-topic']));
			$noteExplanation = addslashes(htmlspecialchars($_POST['note-explanation']));

			if (!empty($noteTopic) && !empty($noteExplanation)) {
				$noteOne = new Note();
				$fingerprint = $dorAuth->dorcrypted->generateUniqToken(32, RANDOM_BYTES);
				$noteOne->setNote(NULL, $currentUserID, NULL ,$noteTopic, $noteExplanation, $fingerprint);
				$saveResult = $noteOne->takeNote();
				$activityReporter->setActivity(NULL, 'NOTE', $currentUserID, NULL, $noteOne->getNoteId());
				$reportResult = $activityReporter->saveActivity();

				if($saveResult && $reportResult) {
					$resultBox = "<div class='message-box info'>
										<h2>Bilgi</h2>
										<p>Notun başarıyla eklendi.</p>
										</div>";
				} elseif(!$saveResult && !$reportResult) {
					$resultBox = "<div class='message-box error'>
										<h2>Hata</h2>
										<p>Bir hata oluştu. Notun eklenemedi.</p>
										</div>";
				} elseif(!$reportResult && $saveResult) {
					$resultBox = "<div class='message-box warning'>
										<h2>Söylemekten Utanıyoruz Ama...</h2>
										<p>Bir hata oluştu. Notun eklendi ancak bu sonsuza kadar böyle sürmeyebilir.</p>
										</div>";
				} elseif(!$saveResult && !$reportResult) {
					$resultBox = "<div class='message-box warning'>
										<h2>Söylemekten Utanıyoruz Ama...</h2>
										<p>İlginç bir sey oldu ve... Notun eklenemedi.</p>
										</div>";
				}
			} else {
			$resultBox = "<div class='message-box warning'>
											<h2>Uyarı</h2>
											<p>Bak, burada oyun oynamıyoruz. Lütfen boş yapma. Ciddiyim.</p>
										</div>";
			}
		} elseif(isset($_POST['delete-note'])) { //not silme
			$noteID = htmlspecialchars($_POST['note-id']);
			if (!empty($noteID)) {
				$noteOne = new Note();
				$noteOne->getNoteById($noteID);
				$activityReporter = new Activity();
				$activityReporter->getActivityByThingId('NOTE', $noteID);
				$reportResult = $activityReporter->deleteActivity();
				$deleteResult = $noteOne->trashNote();
				if($deleteResult == true && $reportResult == true) {
					$resultBox = "<div class='message-box info'>
										<h2>Bilgi</h2>
										<p>Notun başarıyla yok edildi.</p>
									  </div>";
				} elseif (!$deleteResult || !$reportResult) {
					$resultBox = "<div class='message-box error'>
										<h2>Hata</h2>
										<p>Bir hata oluştu. Olup biteni bi' kontrol et.</p>
									  </div>";
				}
			} else {
				$resultBox = "<div class='message-box warning'>
									<h2>Garip</h2>
									<p>Böyle bir not yok.</p>
									</div>";
			}
		}
		$userNotes = $noteRequester->getNoteByUserId($currentUserID);
	}
?>
<!DOCTYPE html>
<html lang="tr" dir="ltr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Notlarım - Dorkodia</title>
    <meta name="robots" content="noimageindex, noarchive">
    <meta name="web-app-capable" content="yes">
    <meta name="theme-color" content="#447b88">
    <meta name="author" content="Doruk Dorkodu">
    <link rel="shortcut icon" href="./image/favicon.gif">
    <link rel="stylesheet" href="./style/base.dorkodia.css">
    <link rel="stylesheet" href="./style/desktop.dorkodia.css">
    <link rel="stylesheet" href="./style/dor.icon.css">
  </head>
  <body>
    <div id="book">
      <?php require_once "./req/header.php"; ?>
      <div id="pod">
        <?php require_once "./req/pod.php"; ?>
      </div>
      <div id="page-body">
        <div id="header">
          <h1>Notlarım</h1>
        </div>
        <div id="content">
          <div class="column base-column">
				<?php require_once REQ_DIR."/error-handler.php"; ?>
            <div class="set" id="dreamwall">
              <h2>Notlarım</h2>
              <?php if(!empty($resultBox)) echo $resultBox;?>
              <!-- yeni not -->
              <div class="dream-new-dream">
                <div class="header-set">
                  <h3>Yeni bir not yaz</h3>
                </div>
                <form name="form-new-note" action="not.php" method="post">
                  <label for="note-topic">Konu :</label>
                  <input type="text" name="note-topic" id="note-topic" class="input-text" autocomplete="off">
                  <label for="note-explanation">Metin :</label>
                  <textarea name="note-explanation" id="note-explanation" class="input-richtext" autocomplete="off" maxlength="256" ></textarea>
                  <button type="submit" name="take-note" class="input-submit">Yaz</button>
                </form>
              </div>

              <!-- not listele -->
              <div class="dreamwall-my-worklist">
                <div class="header-set">
                  <h3>Düşüncelerimden arta kalanlar</h3>
                </div>
                <div class="wlist-content">
                  <ul>
						<?php
							if (is_array($userNotes) && (count($userNotes) > 0)) {
								foreach ($userNotes as $userNote) {
									$tmpNote = new Note();
									$tmpNote->getNoteByArray($userNote);
								  echo '<div class="post do-note">
											 <div class="icon d-pagelines"></div>
											 <div class="post-body">
												<div class="post-info">
												  <img src="" class="user-photo">
												  <p class="p-info-username">'.$currentUser->getUsername().'</p><p class="p-info-timestamp">'.$tmpNote->getCreateTime().'</p>
												</div>
												<div class="post-content">
												  <h5><span>Not &bull; </span>'.$tmpNote->getTitle().'</h5>
												  <p>'.$tmpNote->getContent().'</p>
												</div>
											 </div>
										  </div>
										  <div class="dream-details-controlbox">
											<form action="not.php" method="POST">
												<input type="hidden" value="'.$tmpNote->getNoteId().'" name="note-id"></input>
												<button type="submit" id="work-btn-giveup" name="delete-note" class="input-submit"><i class="icon d-trash-o"></i> Çöpe yolla</button>
											</form>
										  </div>';
								}
							} elseif (!$userNotes) {
								echo "<p style='width:95%; margin:5px auto;'>Not defterin kalbin kadar temiz :D Hemen bir not ekle	!</p>";
							}
						?>
                  </ul>
                </div>
              </div>
              <div class="dream-">

              </div>
            </div>
          </div>
          <div class="column nav-column">
            <?php require_once REQ_DIR.'/nanofeed.php'; ?>
          </div>
        </div>
      </div>
      <?php require_once "./req/footer.php" ?>
    </div>
  </body>
</html>
